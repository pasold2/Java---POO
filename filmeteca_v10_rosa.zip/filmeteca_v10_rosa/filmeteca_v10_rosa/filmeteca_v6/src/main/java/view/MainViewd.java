package view;

public interface MainViewd {
}
