package view;

import javafx.animation.FadeTransition;
import javafx.animation.PauseTransition;
import javafx.animation.ScaleTransition;
import javafx.animation.TranslateTransition;
import javafx.application.Application;
import javafx.application.Platform;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.SnapshotParameters;
import javafx.scene.control.*;
import javafx.scene.effect.DropShadow;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.image.PixelReader;
import javafx.scene.image.WritableImage;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Rectangle;
import javafx.scene.transform.Transform;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import javafx.util.Duration;
import model.Filme;
import model.GerenciadorDados;
import model.SistemaRanking;
import model.SistemaRecomendacao;
import model.TmdbApi;
import model.Usuario;

import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.*;
import java.util.zip.CRC32;
import java.util.zip.DeflaterOutputStream;

public class MainView extends Application {
    private Usuario usuarioLogado;
    private Stage primaryStage;
    private BorderPane appRoot;
    private VBox topoContainer;
    private StackPane contentHost;
    private StackPane appOverlay;
    private Label toastLabel;
    private Button navPesquisa;
    private Button navRanking;
    private Button navPerfil;
    private double dragOffsetX;
    private double dragOffsetY;

    // Perfil
    private ImageView avatarView;
    private ImageView bannerView;
    private StackPane bannerContainer;
    private Label statsLabel;
    private VBox listaFavoritosPerfil;
    private VBox listaRankingPerfil;
    private VBox painelPersonalizacao;

    // Ranking 1v1
    private Filme filmeEsquerda;
    private Filme filmeDireita;
    private static final double LARGURA_POSTER_RANKING = 190;
    private static final double ALTURA_POSTER_RANKING = 285;
    private Label lblFilmeA;
    private Label lblFilmeB;
    private ImageView imgFilmeA;
    private ImageView imgFilmeB;
    private HBox comparacaoBox;
    private Label lblRankingVazio;

    // Pesquisa e Recomendações
    private int paginaAtual = 1;
    private TextField searchField;
    private ComboBox<String> filtroGenero;
    private TextField txtAno;
    private TextField txtDiretor;
    private TextField txtAtor;
    private TextField txtPais;
    private VBox gradeResultados;
    private VBox containerRecomendacoes;
    private List<Filme> cacheCandidatosRecomendacao = null;
    private int assinaturaHistoricoCache = -1;

    private static final String COR_TEXTO_PESQUISA = "#ffd0e8";

    @Override
    public void start(Stage stage) {
        this.primaryStage = stage;
        primaryStage.initStyle(StageStyle.UNDECORATED);
        usuarioLogado = GerenciadorDados.carregarUsuario();

        if (usuarioLogado != null) {
            mostrarTelaPrincipal();
        } else {
            mostrarTelaCadastro();
        }

        primaryStage.setTitle("Filmeteca");
        try {
            Image appIcon = new Image(getClass().getResourceAsStream("/view/app-icon.png"));
            primaryStage.getIcons().add(appIcon);
        } catch (Exception ignored) { }
        primaryStage.show();
    }

    private void mostrarTelaCadastro() {
        VBox layout = new VBox(20);
        layout.setAlignment(Pos.CENTER);
        layout.setPadding(new Insets(50));

        Label titulo = new Label("Boas-vindas à Filmeteca");
        titulo.getStyleClass().add("label-title");

        Label sub = new Label("Crie seu perfil para começar seu catálogo pessoal");
        sub.getStyleClass().add("label-info");

        TextField txtNome = new TextField();
        txtNome.setPromptText("Digite seu nome...");
        txtNome.setMaxWidth(320);

        TextField txtIdade = new TextField();
        txtIdade.setPromptText("Digite sua idade...");
        txtIdade.setMaxWidth(320);

        Button btnEntrar = new Button("Criar Perfil e Entrar");
        btnEntrar.setOnAction(e -> {
            String nome = txtNome.getText().trim();
            String idadeStr = txtIdade.getText().trim();

            if (!nome.isEmpty() && !idadeStr.isEmpty()) {
                try {
                    int idade = Integer.parseInt(idadeStr);
                    if (idade <= 0 || idade > 130) {
                        new Alert(Alert.AlertType.ERROR, "Por favor, insira uma idade válida.").show();
                        return;
                    }
                    usuarioLogado = new Usuario(nome, idade);
                    GerenciadorDados.salvarUsuario(usuarioLogado);
                    mostrarTelaPrincipal();
                } catch (NumberFormatException ex) {
                    new Alert(Alert.AlertType.ERROR, "Por favor, insira uma idade válida (número).").show();
                }
            } else {
                new Alert(Alert.AlertType.WARNING, "Preencha todos os campos para continuar.").show();
            }
        });

        layout.getChildren().addAll(titulo, sub, txtNome, txtIdade, btnEntrar);
        BorderPane cadastroRoot = new BorderPane();
        cadastroRoot.getStyleClass().add("app-root");
        cadastroRoot.setTop(criarBarraSuperior());
        cadastroRoot.setCenter(layout);
        Scene scene = new Scene(cadastroRoot, 1050, 750);
        scene.getStylesheets().add(getClass().getResource("/view/style.css").toExternalForm());
        primaryStage.setScene(scene);
    }

    private void mostrarTelaPrincipal() {
        appRoot = new BorderPane();
        appRoot.getStyleClass().add("app-root");
        topoContainer = new VBox(0, criarBarraSuperior(), criarAbasTopo());
        appRoot.setTop(topoContainer);

        contentHost = new StackPane();
        contentHost.getStyleClass().add("content-host");
        appRoot.setCenter(contentHost);

        appOverlay = new StackPane();
        appOverlay.setPickOnBounds(false);
        toastLabel = new Label();
        toastLabel.getStyleClass().add("toast-message");
        toastLabel.setVisible(false);
        toastLabel.setManaged(false);
        StackPane.setAlignment(toastLabel, Pos.TOP_RIGHT);
        StackPane.setMargin(toastLabel, new Insets(18, 22, 0, 0));
        appOverlay.getChildren().add(toastLabel);

        StackPane root = new StackPane(appRoot, appOverlay);
        Scene scene = new Scene(root, 1200, 800);
        scene.getStylesheets().add(getClass().getResource("/view/style.css").toExternalForm());
        primaryStage.setScene(scene);

        aplicarTemaDinamico();
        mostrarPagina("pesquisa");
    }

    private String getEstiloFundoDestaque() {
        String c1 = usuarioLogado != null ? usuarioLogado.getCorPrimaria() : "#c83f8d";
        String c2 = usuarioLogado != null ? usuarioLogado.getCorSecundaria() : "#e860a8";
        boolean grad = usuarioLogado == null || usuarioLogado.isGradienteAtivo();
        String dir = usuarioLogado != null ? usuarioLogado.getDirecaoGradiente() : "VERTICAL";

        if (!grad) {
            return c1;
        }
        String direcaoCss = switch (dir) {
            case "HORIZONTAL" -> "to right";
            case "DIAGONAL_CIMA" -> "to top right";
            case "DIAGONAL_BAIXO" -> "to bottom right";
            default -> "to bottom";
        };
        return "linear-gradient(" + direcaoCss + ", " + c2 + ", " + c1 + ")";
    }

    private DropShadow criarSombraDinamica() {
        String tipo = usuarioLogado != null ? usuarioLogado.getTipoSombra() : "INFERIOR";
        if ("NENHUMA".equals(tipo)) return null;

        Color corSombra = Color.web(usuarioLogado != null ? usuarioLogado.getCorPrimaria() : "#c83f8d", 0.35);
        DropShadow ds = new DropShadow();
        ds.setColor(corSombra);
        ds.setRadius(14);
        ds.setSpread(0.12);
        switch (tipo) {
            case "SUPERIOR" -> { ds.setOffsetX(0); ds.setOffsetY(-4); }
            case "ESQUERDA" -> { ds.setOffsetX(-4); ds.setOffsetY(0); }
            case "DIREITA" -> { ds.setOffsetX(4); ds.setOffsetY(0); }
            default -> { ds.setOffsetX(0); ds.setOffsetY(4); }
        }
        return ds;
    }

    private void estilizarBotaoPrincipal(Button btn) {
        if (btn == null) return;
        btn.setStyle("-fx-background-color: " + getEstiloFundoDestaque() + "; -fx-text-fill: white; -fx-font-weight: bold;");
        btn.setEffect(criarSombraDinamica());
    }

    private void aplicarTemaDinamico() {
        if (usuarioLogado == null || appRoot == null) return;
        String primaria = usuarioLogado.getCorPrimaria();
        String fundoDestaque = getEstiloFundoDestaque();

        Button[] abas = {navPesquisa, navRanking, navPerfil};
        for (Button b : abas) {
            if (b != null) {
                if (b.getStyleClass().contains("active")) {
                    b.setStyle("-fx-background-color: " + fundoDestaque + "; -fx-text-fill: white; -fx-background-radius: 24;");
                    b.setEffect(criarSombraDinamica());
                } else {
                    b.setStyle("-fx-background-color: transparent; -fx-text-fill: #e8c9dc; -fx-background-radius: 24;");
                    b.setEffect(null);
                }
            }
        }

        if (topoContainer != null && !topoContainer.getChildren().isEmpty()) {
            Node barra = topoContainer.getChildren().get(0);
            barra.setStyle("-fx-border-color: transparent transparent " + primaria + " transparent; -fx-border-width: 0 0 1 0;");
        }
        if (toastLabel != null) {
            toastLabel.setStyle("-fx-border-color: " + primaria + ";");
        }
    }

    private HBox criarBarraSuperior() {
        HBox barra = new HBox(14);
        barra.setAlignment(Pos.CENTER_LEFT);
        barra.setPadding(new Insets(0, 14, 0, 18));
        barra.getStyleClass().add("title-bar");
        try {
            ImageView logo = new ImageView(new Image(getClass().getResourceAsStream("/view/app-icon.png")));
            logo.setFitWidth(25);
            logo.setFitHeight(25);
            logo.setPreserveRatio(true);
            barra.getChildren().add(logo);
        } catch (Exception ignored) { }

        Label nome = new Label("FILMETECA");
        nome.getStyleClass().add("brand-title");
        Region spacer = new Region();
        HBox.setHgrow(spacer, Priority.ALWAYS);
        Label minimizar = new Label("—");
        minimizar.getStyleClass().add("window-control");
        Label maximizar = new Label("□");
        maximizar.getStyleClass().add("window-control");
        Label fechar = new Label("×");
        fechar.getStyleClass().add("window-close");

        minimizar.setOnMouseClicked(e -> primaryStage.setIconified(true));
        maximizar.setOnMouseClicked(e -> primaryStage.setMaximized(!primaryStage.isMaximized()));
        fechar.setOnMouseClicked(e -> primaryStage.close());

        barra.getChildren().addAll(nome, spacer, minimizar, maximizar, fechar);
        barra.setOnMousePressed(e -> {
            dragOffsetX = e.getSceneX();
            dragOffsetY = e.getSceneY();
        });
        barra.setOnMouseDragged(e -> {
            if (!primaryStage.isMaximized()) {
                primaryStage.setX(e.getScreenX() - dragOffsetX);
                primaryStage.setY(e.getScreenY() - dragOffsetY);
            }
        });
        return barra;
    }

    private HBox criarAbasTopo() {
        HBox abas = new HBox();
        abas.setAlignment(Pos.CENTER_LEFT);
        abas.getStyleClass().add("top-tabs");
        abas.setMaxWidth(Region.USE_PREF_SIZE);
        abas.setMaxHeight(Region.USE_PREF_SIZE);
        navPesquisa = criarBotaoNavegacao("Explorar", "pesquisa");
        navRanking = criarBotaoNavegacao("Ranking", "ranking");
        navPerfil = criarBotaoNavegacao("Meu Perfil", "perfil");
        abas.getChildren().addAll(navPesquisa, navRanking, navPerfil);

        HBox faixa = new HBox(abas);
        faixa.setAlignment(Pos.CENTER_LEFT);
        faixa.getStyleClass().add("tabs-area");
        return faixa;
    }

    private Button criarBotaoNavegacao(String texto, String pagina) {
        Button botao = new Button(texto);
        botao.setAlignment(Pos.CENTER);
        botao.getStyleClass().add("nav-button");
        botao.setOnAction(e -> mostrarPagina(pagina));
        return botao;
    }

    private void atualizarAbaAtiva(Button selecionado) {
        navPesquisa.getStyleClass().remove("active");
        navRanking.getStyleClass().remove("active");
        navPerfil.getStyleClass().remove("active");

        if (!selecionado.getStyleClass().contains("active")) {
            selecionado.getStyleClass().add("active");
        }
        aplicarTemaDinamico();
    }

    private void mostrarPagina(String pagina) {
        if ("ranking".equals(pagina)) {
            atualizarAbaAtiva(navRanking);
        } else if ("perfil".equals(pagina)) {
            atualizarAbaAtiva(navPerfil);
        } else {
            atualizarAbaAtiva(navPesquisa);
        }

        Node tela;
        if ("ranking".equals(pagina)) {
            VBox rankingView = criarAbaRanking();
            sortearFilmesRanking();
            tela = rankingView;
        } else if ("perfil".equals(pagina)) {
            tela = criarAbaPerfil();
        } else {
            tela = criarAbaPesquisa();
        }

        tela.setOpacity(0);
        tela.setTranslateY(8);
        contentHost.getChildren().setAll(tela);

        FadeTransition fade = new FadeTransition(Duration.millis(220), tela);
        fade.setFromValue(0.0);
        fade.setToValue(1.0);
        fade.play();
    }

    private void mostrarToast(String mensagem) {
        if (toastLabel == null) return;
        toastLabel.setText("✓  " + mensagem);
        toastLabel.setVisible(true);
        toastLabel.setManaged(true);
        toastLabel.setOpacity(0);
        toastLabel.setTranslateY(-8);
        FadeTransition entrada = new FadeTransition(Duration.millis(180), toastLabel);
        entrada.setToValue(1);
        TranslateTransition deslizar = new TranslateTransition(Duration.millis(180), toastLabel);
        deslizar.setToY(0);
        entrada.play();
        deslizar.play();
        PauseTransition pausa = new PauseTransition(Duration.seconds(2.4));
        pausa.setOnFinished(e -> {
            FadeTransition saida = new FadeTransition(Duration.millis(250), toastLabel);
            saida.setToValue(0);
            saida.setOnFinished(ev -> {
                toastLabel.setVisible(false);
                toastLabel.setManaged(false);
            });
            saida.play();
        });
        pausa.play();
    }

    private ScrollPane criarAbaPesquisa() {
        VBox layout = new VBox(16);
        layout.setPadding(new Insets(20, 26, 28, 26));
        layout.getStyleClass().add("search-page");

        Label tituloAba = new Label("Explorar e Filtrar Catálogo");
        tituloAba.getStyleClass().add("label-title");

        GridPane gridFiltros = new GridPane();
        gridFiltros.setHgap(14);
        gridFiltros.setVgap(10);

        searchField = new TextField();
        searchField.setPromptText("Título do filme (opcional)...");
        searchField.setPrefWidth(230);

        filtroGenero = new ComboBox<>();
        filtroGenero.getItems().addAll("Todos", "Ação", "Comédia", "Terror", "Drama", "Ficção científica",
                "Mistério", "Aventura", "Animação", "Romance", "Thriller", "Crime", "Fantasia");
        filtroGenero.setValue("Todos");
        filtroGenero.setPrefWidth(170);

        txtAno = new TextField();
        txtAno.setPromptText("Ano (ex: 1977)");
        txtAno.setPrefWidth(115);

        txtDiretor = new TextField();
        txtDiretor.setPromptText("Diretor...");
        txtDiretor.setPrefWidth(150);

        txtAtor = new TextField();
        txtAtor.setPromptText("Ator / Atriz...");
        txtAtor.setPrefWidth(150);

        txtPais = new TextField();
        txtPais.setPromptText("Ex.: Japão, Brasil...");
        txtPais.setPrefWidth(150);

        Button btnBuscar = new Button("Buscar Filmes");
        estilizarBotaoPrincipal(btnBuscar);

        gridFiltros.add(criarRotuloPesquisa("Título:"), 0, 0);
        gridFiltros.add(searchField, 0, 1);
        gridFiltros.add(criarRotuloPesquisa("Gênero:"), 1, 0);
        gridFiltros.add(filtroGenero, 1, 1);
        gridFiltros.add(criarRotuloPesquisa("Ano:"), 2, 0);
        gridFiltros.add(txtAno, 2, 1);
        gridFiltros.add(criarRotuloPesquisa("Diretor:"), 3, 0);
        gridFiltros.add(txtDiretor, 3, 1);
        gridFiltros.add(criarRotuloPesquisa("Ator / Atriz:"), 4, 0);
        gridFiltros.add(txtAtor, 4, 1);
        gridFiltros.add(criarRotuloPesquisa("País de origem:"), 5, 0);
        gridFiltros.add(txtPais, 5, 1);
        gridFiltros.add(btnBuscar, 6, 1);

        containerRecomendacoes = new VBox(10);
        containerRecomendacoes.getStyleClass().add("card-filme");
        containerRecomendacoes.setStyle("-fx-border-color: " + usuarioLogado.getCorPrimaria() + ";");
        carregarSecaoRecomendacoes(false);

        gradeResultados = new VBox(15);

        Button btnCarregarMais = new Button("Carregar Mais Resultados");
        btnCarregarMais.setMaxWidth(Double.MAX_VALUE);
        btnCarregarMais.setVisible(false);
        btnCarregarMais.setManaged(false);
        estilizarBotaoPrincipal(btnCarregarMais);

        btnBuscar.setOnAction(e -> {
            paginaAtual = 1;
            gradeResultados.getChildren().clear();
            btnCarregarMais.setVisible(true);
            btnCarregarMais.setManaged(true);
            executarBusca(false, btnCarregarMais);
        });

        btnCarregarMais.setOnAction(e -> {
            paginaAtual++;
            executarBusca(true, btnCarregarMais);
        });

        layout.getChildren().addAll(tituloAba, gridFiltros, containerRecomendacoes, gradeResultados, btnCarregarMais);

        ScrollPane scroll = new ScrollPane(layout);
        scroll.setFitToWidth(true);
        scroll.setHbarPolicy(ScrollPane.ScrollBarPolicy.NEVER);
        return scroll;
    }

    private void carregarSecaoRecomendacoes(boolean forcarRecarga) {
        if (containerRecomendacoes == null) return;
        containerRecomendacoes.getChildren().clear();

        HBox headerRec = new HBox(12);
        headerRec.setAlignment(Pos.CENTER_LEFT);
        Label tituloRec = new Label("Recomendados para Você");
        tituloRec.getStyleClass().add("label-subtitle");
        tituloRec.setStyle("-fx-text-fill: " + usuarioLogado.getCorSecundaria() + ";");

        Label subRec = new Label("Fatoração de Matrizes (SVD) + Similaridade de Cosseno");
        subRec.getStyleClass().add("label-info");

        Region spacer = new Region();
        HBox.setHgrow(spacer, Priority.ALWAYS);

        Button btnAtualizarRec = new Button("Atualizar Sugestões");
        btnAtualizarRec.getStyleClass().add("secondary-button");
        btnAtualizarRec.setOnAction(e -> carregarSecaoRecomendacoes(true));

        headerRec.getChildren().addAll(tituloRec, subRec, spacer, btnAtualizarRec);

        Label carregando = criarRotuloPesquisa("Calculando afinidades com seu histórico...");
        containerRecomendacoes.getChildren().addAll(headerRec, carregando);

        int assinaturaAtual = usuarioLogado.getFilmesVistos().hashCode();

        new Thread(() -> {
            try {
                if (forcarRecarga || cacheCandidatosRecomendacao == null || assinaturaHistoricoCache != assinaturaAtual) {
                    cacheCandidatosRecomendacao = TmdbApi.buscarCandidatosRecomendacao(usuarioLogado);
                    assinaturaHistoricoCache = assinaturaAtual;
                }

                List<SistemaRecomendacao.ResultadoRecomendacao> recs =
                        SistemaRecomendacao.recomendar(usuarioLogado, cacheCandidatosRecomendacao, 5);

                Platform.runLater(() -> {
                    containerRecomendacoes.getChildren().remove(carregando);
                    if (recs.isEmpty()) {
                        containerRecomendacoes.getChildren().add(criarRotuloPesquisa("Nenhuma recomendação disponível no momento."));
                        return;
                    }

                    if (recs.get(0).isModoFallback()) {
                        Label avisoFallback = new Label(recs.get(0).getJustificativa());
                        avisoFallback.getStyleClass().add("label-info");
                        containerRecomendacoes.getChildren().add(avisoFallback);
                    }

                    HBox faixaCards = new HBox(14);
                    faixaCards.setAlignment(Pos.TOP_LEFT);

                    for (SistemaRecomendacao.ResultadoRecomendacao rec : recs) {
                        faixaCards.getChildren().add(criarMiniCardRecomendacao(rec));
                    }

                    ScrollPane scrollHorizontal = new ScrollPane(faixaCards);
                    scrollHorizontal.setFitToHeight(true);
                    scrollHorizontal.setVbarPolicy(ScrollPane.ScrollBarPolicy.NEVER);
                    scrollHorizontal.setHbarPolicy(ScrollPane.ScrollBarPolicy.AS_NEEDED);
                    scrollHorizontal.setPrefHeight(335);
                    containerRecomendacoes.getChildren().add(scrollHorizontal);
                });
            } catch (Exception ex) {
                Platform.runLater(() -> {
                    containerRecomendacoes.getChildren().remove(carregando);
                    containerRecomendacoes.getChildren().add(criarRotuloPesquisa("Não foi possível carregar recomendações agora."));
                });
            }
        }).start();
    }

    private VBox criarMiniCardRecomendacao(SistemaRecomendacao.ResultadoRecomendacao rec) {
        Filme f = rec.getFilme();
        VBox box = new VBox(8);
        box.setPrefWidth(215);
        box.setMinWidth(215);
        box.setMaxWidth(215);
        box.setPadding(new Insets(12));
        box.setStyle("-fx-background-color: #141019; -fx-border-color: " + usuarioLogado.getCorPrimaria()
                + "; -fx-border-radius: 10; -fx-background-radius: 10;");
        box.setEffect(criarSombraDinamica());

        ImageView poster = new ImageView();
        poster.setFitWidth(100);
        poster.setFitHeight(148);
        poster.setPreserveRatio(true);
        if (f.getPosterUrl() != null) {
            poster.setImage(new Image(f.getPosterUrl(), 100, 148, true, true, true));
        }
        HBox posterCenter = new HBox(poster);
        posterCenter.setAlignment(Pos.CENTER);

        Label titulo = new Label(f.getTitulo() + " (" + f.getAno() + ")");
        titulo.getStyleClass().add("label-bold");
        titulo.setWrapText(true);
        titulo.setMaxHeight(40);

        Label meta = new Label("TMDB: " + String.format("%.1f", f.getNotaGeral()) + " • " + String.join(", ", f.getGeneros()));
        meta.getStyleClass().add("label-info");
        meta.setStyle("-fx-font-size: 11px;");
        meta.setWrapText(true);

        Label motivo = new Label(rec.getJustificativa());
        motivo.getStyleClass().add("label-info");
        motivo.setStyle("-fx-font-size: 11px; -fx-text-fill: " + usuarioLogado.getCorSecundaria() + ";");
        motivo.setWrapText(true);
        VBox.setVgrow(motivo, Priority.ALWAYS);

        Button btnMarcar = new Button(f.isVisto() ? "Assistido ✓" : "+ Marcar Visto");
        btnMarcar.setMaxWidth(Double.MAX_VALUE);
        btnMarcar.setStyle("-fx-font-size: 11px; -fx-padding: 6 10 6 10; -fx-background-color: " + getEstiloFundoDestaque() + ";");
        if (f.isVisto()) btnMarcar.setDisable(true);
        btnMarcar.setOnAction(e -> {
            usuarioLogado.adicionarFilmeVisto(f);
            GerenciadorDados.salvarUsuario(usuarioLogado);
            btnMarcar.setText("Assistido ✓");
            btnMarcar.setDisable(true);
            mostrarToast("Filme salvo no seu perfil");
            carregarSecaoRecomendacoes(false);
        });

        box.getChildren().addAll(posterCenter, titulo, meta, motivo, btnMarcar);
        return box;
    }

    private Label criarRotuloPesquisa(String texto) {
        Label rotulo = new Label(texto);
        rotulo.getStyleClass().add("campo-rotulo");
        rotulo.setTextFill(Color.web(COR_TEXTO_PESQUISA));
        return rotulo;
    }

    private void executarBusca(boolean append, Button btnCarregarMais) {
        if (!append) {
            gradeResultados.getChildren().add(criarRotuloPesquisa("Consultando acervo..."));
        }

        new Thread(() -> {
            try {
                List<Filme> resultados = TmdbApi.buscarFilmes(
                        searchField.getText(),
                        filtroGenero.getValue(),
                        txtAno.getText(),
                        txtDiretor.getText(),
                        txtAtor.getText(),
                        txtPais.getText(),
                        paginaAtual
                );

                Platform.runLater(() -> {
                    if (!append) {
                        gradeResultados.getChildren().clear();
                    } else {
                        gradeResultados.getChildren().removeIf(node -> node instanceof Label && ((Label) node).getText().contains("Consultando"));
                    }

                    if (resultados.isEmpty() && !append) {
                        gradeResultados.getChildren().add(criarRotuloPesquisa("Nenhum filme encontrado com os filtros aplicados."));
                        btnCarregarMais.setDisable(true);
                        return;
                    }

                    if (resultados.isEmpty()) {
                        btnCarregarMais.setDisable(true);
                        return;
                    }

                    for (Filme f : resultados) {
                        gradeResultados.getChildren().add(criarCardFilme(f));
                    }
                    btnCarregarMais.setDisable(resultados.size() < 10);
                });
            } catch (Exception ex) {
                Platform.runLater(() -> {
                    if (!append) gradeResultados.getChildren().clear();
                    gradeResultados.getChildren().add(criarRotuloPesquisa("Erro ao buscar filmes: " + ex.getMessage()));
                });
            }
        }).start();
    }

    private VBox criarCardFilme(Filme filme) {
        for (Filme fVisto : usuarioLogado.getFilmesVistos()) {
            if (fVisto.getId() == filme.getId()) {
                filme = fVisto;
                break;
            }
        }

        VBox card = new VBox(10);
        card.getStyleClass().add("card-filme");
        card.setEffect(criarSombraDinamica());

        HBox conteudoCard = new HBox(15);

        ImageView posterView = new ImageView();
        posterView.setFitWidth(120);
        posterView.setFitHeight(180);
        posterView.setPreserveRatio(true);

        if (filme.getPosterUrl() != null) {
            Image img = new Image(filme.getPosterUrl(), 120, 180, true, true, true);
            posterView.setImage(img);
        }

        VBox infoBox = new VBox(6);
        HBox.setHgrow(infoBox, Priority.ALWAYS);

        Label titulo = new Label(filme.getTitulo() + " (" + filme.getAno() + ")");
        titulo.getStyleClass().add("label-subtitle");

        Label detalhes = new Label("Nota Geral: " + filme.getNotaGeral() + " | Diretor: " + filme.getDiretor());
        detalhes.getStyleClass().add("label-bold");

        Label generosELocais = new Label("Gêneros: " + String.join(", ", filme.getGeneros()) +
                (!filme.getPaises().isEmpty() ? " | Origem: " + String.join(", ", filme.getPaises()) : ""));
        generosELocais.getStyleClass().add("label-info");

        if (!filme.getElenco().isEmpty()) {
            Label elenco = new Label("Elenco: " + String.join(", ", filme.getElenco()));
            elenco.getStyleClass().add("label-info");
            infoBox.getChildren().add(elenco);
        }

        Label sinopse = new Label(filme.getSinopse());
        sinopse.setWrapText(true);
        sinopse.getStyleClass().add("label-info");

        infoBox.getChildren().addAll(0, List.of(titulo, detalhes, generosELocais));
        infoBox.getChildren().add(sinopse);

        conteudoCard.getChildren().addAll(posterView, infoBox);

        VBox areaAvaliacao = new VBox(8);
        areaAvaliacao.setVisible(false);
        areaAvaliacao.setManaged(false);

        HBox linhaNota = new HBox(10);
        linhaNota.setAlignment(Pos.CENTER_LEFT);

        TextField txtNota = new TextField();
        txtNota.setPromptText("Sua nota (0 a 10)");
        txtNota.setMaxWidth(160);

        Button btnSalvarReview = new Button("Salvar Nota e Comentário");
        estilizarBotaoPrincipal(btnSalvarReview);

        linhaNota.getChildren().addAll(criarRotuloPesquisa("Sua Nota:"), txtNota, btnSalvarReview);

        TextArea txtComentario = new TextArea();
        txtComentario.setPromptText("Escreva seu comentário pessoal sobre o filme...");
        txtComentario.setPrefRowCount(2);

        if (filme.getNotaUsuario() != null) {
            txtNota.setText(String.valueOf(filme.getNotaUsuario()));
        }
        if (filme.getComentario() != null) {
            txtComentario.setText(filme.getComentario());
        }

        areaAvaliacao.getChildren().addAll(linhaNota, txtComentario);

        final Filme filmeRef = filme;
        HBox barraAcoesCard = new HBox(10);
        barraAcoesCard.setAlignment(Pos.CENTER_LEFT);

        Button btnVisto = new Button(filmeRef.isVisto() ? "Assistido ✓" : "Marcar como Assistido");
        estilizarBotaoPrincipal(btnVisto);

        Button btnFavorito = new Button(filmeRef.isFavorito() ? "★ Favorito" : "☆ Favoritar");
        btnFavorito.getStyleClass().add("secondary-button");
        btnFavorito.setVisible(filmeRef.isVisto());
        btnFavorito.setManaged(filmeRef.isVisto());

        if (filmeRef.isVisto()) {
            btnVisto.setDisable(true);
            areaAvaliacao.setVisible(true);
            areaAvaliacao.setManaged(true);
        }

        btnVisto.setOnAction(e -> {
            usuarioLogado.adicionarFilmeVisto(filmeRef);
            GerenciadorDados.salvarUsuario(usuarioLogado);
            btnVisto.setText("Assistido ✓");
            btnVisto.setDisable(true);
            btnFavorito.setVisible(true);
            btnFavorito.setManaged(true);
            areaAvaliacao.setVisible(true);
            areaAvaliacao.setManaged(true);
            mostrarToast("Filme salvo no seu perfil");
        });

        btnFavorito.setOnAction(e -> {
            filmeRef.setFavorito(!filmeRef.isFavorito());
            GerenciadorDados.salvarUsuario(usuarioLogado);
            btnFavorito.setText(filmeRef.isFavorito() ? "★ Favorito" : "☆ Favoritar");
            mostrarToast(filmeRef.isFavorito() ? "Adicionado aos favoritos" : "Removido dos favoritos");
        });

        btnSalvarReview.setOnAction(e -> {
            try {
                double nota = Double.parseDouble(txtNota.getText().replace(",", "."));
                if (nota < 0.0 || nota > 10.0) {
                    new Alert(Alert.AlertType.ERROR, "A nota deve ser um valor entre 0 e 10.").show();
                    return;
                }
                String comentario = txtComentario.getText().trim();
                filmeRef.avaliarEComentar(nota, comentario);
                GerenciadorDados.salvarUsuario(usuarioLogado);
                mostrarToast("Avaliação salva no seu perfil");
            } catch (NumberFormatException ex) {
                new Alert(Alert.AlertType.ERROR, "Insira um número válido para a nota entre 0 e 10.").show();
            }
        });

        barraAcoesCard.getChildren().addAll(btnVisto, btnFavorito);
        card.getChildren().addAll(conteudoCard, barraAcoesCard, areaAvaliacao);
        return card;
    }

    private VBox criarAbaRanking() {
        VBox layout = new VBox(24);
        layout.setPadding(new Insets(30));
        layout.setAlignment(Pos.CENTER);

        Label titulo = new Label("Ranking");
        titulo.getStyleClass().add("label-title");

        Label explicacao = new Label("Qual destes dois filmes você prefere? Escolha o vencedor do duelo; sua lista completa fica em Meu Perfil.");
        explicacao.getStyleClass().add("label-info");
        explicacao.setWrapText(true);

        comparacaoBox = new HBox(50);
        comparacaoBox.setAlignment(Pos.CENTER);

        VBox boxA = new VBox(12);
        boxA.setAlignment(Pos.CENTER);
        imgFilmeA = new ImageView();
        imgFilmeA.setFitWidth(LARGURA_POSTER_RANKING);
        imgFilmeA.setFitHeight(ALTURA_POSTER_RANKING);
        imgFilmeA.setPreserveRatio(true);
        lblFilmeA = new Label("?");
        lblFilmeA.getStyleClass().add("label-subtitle");
        Label dicaA = new Label("Clique no pôster para escolher");
        dicaA.getStyleClass().add("label-info");
        imgFilmeA.getStyleClass().add("poster-ranking");
        boxA.getChildren().addAll(imgFilmeA, lblFilmeA, dicaA);

        Label vs = new Label("VS");
        vs.getStyleClass().add("label-title");

        VBox boxB = new VBox(12);
        boxB.setAlignment(Pos.CENTER);
        imgFilmeB = new ImageView();
        imgFilmeB.setFitWidth(LARGURA_POSTER_RANKING);
        imgFilmeB.setFitHeight(ALTURA_POSTER_RANKING);
        imgFilmeB.setPreserveRatio(true);
        lblFilmeB = new Label("?");
        lblFilmeB.getStyleClass().add("label-subtitle");
        Label dicaB = new Label("Clique no pôster para escolher");
        dicaB.getStyleClass().add("label-info");
        imgFilmeB.getStyleClass().add("poster-ranking");
        boxB.getChildren().addAll(imgFilmeB, lblFilmeB, dicaB);

        comparacaoBox.getChildren().addAll(boxA, vs, boxB);
        configurarCliquePoster(imgFilmeA, true);
        configurarCliquePoster(imgFilmeB, false);

        lblRankingVazio = new Label("Marque ao menos 2 filmes como assistidos na aba Explorar para começar os duelos.");
        lblRankingVazio.getStyleClass().add("label-info");
        lblRankingVazio.setWrapText(true);
        lblRankingVazio.setVisible(false);
        lblRankingVazio.setManaged(false);

        layout.getChildren().addAll(titulo, explicacao, comparacaoBox, lblRankingVazio);
        return layout;
    }

    private void sortearFilmesRanking() {
        List<Filme> vistos = new ArrayList<>(usuarioLogado.getFilmesVistos());
        boolean haDuelo = vistos.size() >= 2;

        comparacaoBox.setVisible(haDuelo);
        comparacaoBox.setManaged(haDuelo);
        lblRankingVazio.setVisible(!haDuelo);
        lblRankingVazio.setManaged(!haDuelo);

        if (!haDuelo) {
            imgFilmeA.setImage(null);
            imgFilmeB.setImage(null);
            filmeEsquerda = null;
            filmeDireita = null;
            return;
        }

        Collections.shuffle(vistos);
        filmeEsquerda = vistos.get(0);
        filmeDireita = vistos.get(1);

        lblFilmeA.setText(filmeEsquerda.getTitulo());
        lblFilmeB.setText(filmeDireita.getTitulo());

        imgFilmeA.setImage(carregarPosterRanking(filmeEsquerda));
        imgFilmeB.setImage(carregarPosterRanking(filmeDireita));
    }

    private Image carregarPosterRanking(Filme filme) {
        if (filme.getPosterUrl() == null || filme.getPosterUrl().isBlank()) return null;
        return new Image(filme.getPosterUrl(), LARGURA_POSTER_RANKING, ALTURA_POSTER_RANKING, true, true, true);
    }

    private void configurarCliquePoster(ImageView poster, boolean escolherEsquerda) {
        poster.setCursor(javafx.scene.Cursor.HAND);
        poster.setOnMouseEntered(e -> {
            ScaleTransition crescer = new ScaleTransition(Duration.millis(180), poster);
            crescer.setToX(1.07);
            crescer.setToY(1.07);
            crescer.play();
        });
        poster.setOnMouseExited(e -> {
            ScaleTransition voltar = new ScaleTransition(Duration.millis(180), poster);
            voltar.setToX(1.0);
            voltar.setToY(1.0);
            voltar.play();
        });
        poster.setOnMouseClicked(e -> {
            if (filmeEsquerda == null || filmeDireita == null) return;
            Filme vencedor = escolherEsquerda ? filmeEsquerda : filmeDireita;
            Filme perdedor = escolherEsquerda ? filmeDireita : filmeEsquerda;
            ScaleTransition selecionar = new ScaleTransition(Duration.millis(120), poster);
            selecionar.setToX(0.94);
            selecionar.setToY(0.94);
            selecionar.setAutoReverse(true);
            selecionar.setCycleCount(2);
            selecionar.setOnFinished(ev -> {
                SistemaRanking.processarConfronto(vencedor, perdedor);
                GerenciadorDados.salvarUsuario(usuarioLogado);
                mostrarToast("Duelo registrado: " + vencedor.getTitulo() + " venceu!");
                sortearFilmesRanking();
            });
            selecionar.play();
        });
    }

    private ScrollPane criarAbaPerfil() {
        VBox layout = new VBox(22);
        layout.setPadding(new Insets(24, 30, 36, 30));

        bannerContainer = new StackPane();
        bannerContainer.setMinHeight(175);
        bannerContainer.setPrefHeight(175);
        bannerContainer.setMaxHeight(175);
        bannerContainer.setStyle("-fx-background-color: " + getEstiloFundoDestaque()
                + "; -fx-background-radius: 14; -fx-border-radius: 14; -fx-border-color: " + usuarioLogado.getCorPrimaria() + ";");
        bannerContainer.setEffect(criarSombraDinamica());

        bannerView = new ImageView();
        bannerView.setFitHeight(175);
        bannerView.setPreserveRatio(false);
        bannerView.fitWidthProperty().bind(bannerContainer.widthProperty());
        Rectangle clipBanner = new Rectangle();
        clipBanner.widthProperty().bind(bannerContainer.widthProperty());
        clipBanner.setHeight(175);
        clipBanner.setArcWidth(26);
        clipBanner.setArcHeight(26);
        bannerView.setClip(clipBanner);
        atualizarBanner();

        HBox controlesBanner = new HBox(8);
        controlesBanner.setAlignment(Pos.BOTTOM_RIGHT);
        controlesBanner.setPadding(new Insets(10));
        Button btnAlterarBanner = new Button("Alterar Banner");
        btnAlterarBanner.getStyleClass().add("secondary-button");
        btnAlterarBanner.setOnAction(e -> escolherBannerPerfil());

        Button btnRemoverBanner = new Button("Remover Banner");
        btnRemoverBanner.getStyleClass().add("secondary-button");
        btnRemoverBanner.setOnAction(e -> removerBannerPerfil());

        controlesBanner.getChildren().addAll(btnAlterarBanner, btnRemoverBanner);
        bannerContainer.getChildren().addAll(bannerView, controlesBanner);

        HBox cabecalho = new HBox(20);
        cabecalho.setAlignment(Pos.CENTER_LEFT);

        avatarView = new ImageView();
        avatarView.setFitWidth(112);
        avatarView.setFitHeight(112);
        avatarView.setPreserveRatio(false);
        avatarView.setClip(new Circle(56, 56, 56));
        atualizarAvatar();

        VBox identidade = new VBox(8);
        Label nomeLabel = new Label(usuarioLogado.getNome() + ", " + usuarioLogado.getIdade() + " anos");
        nomeLabel.getStyleClass().add("label-title");

        statsLabel = new Label();
        statsLabel.getStyleClass().add("label-info");

        HBox botoesPerfil = new HBox(10);
        Button alterarFoto = new Button("Alterar Foto de Perfil");
        alterarFoto.getStyleClass().add("secondary-button");
        alterarFoto.setOnAction(e -> escolherFotoPerfil());

        Button btnPersonalizar = new Button("Personalizar Aparência");
        btnPersonalizar.getStyleClass().add("secondary-button");

        Button btnExportarPng = new Button("Exportar Perfil (PNG)");
        estilizarBotaoPrincipal(btnExportarPng);
        btnExportarPng.setOnAction(e -> exportarPerfilPng());

        botoesPerfil.getChildren().addAll(alterarFoto, btnPersonalizar, btnExportarPng);
        identidade.getChildren().addAll(nomeLabel, statsLabel, botoesPerfil);
        HBox.setHgrow(identidade, Priority.ALWAYS);
        cabecalho.getChildren().addAll(avatarView, identidade);

        painelPersonalizacao = criarPainelPersonalizacao();
        painelPersonalizacao.setVisible(false);
        painelPersonalizacao.setManaged(false);
        btnPersonalizar.setOnAction(e -> {
            boolean visivel = !painelPersonalizacao.isVisible();
            painelPersonalizacao.setVisible(visivel);
            painelPersonalizacao.setManaged(visivel);
        });

        Label tituloFav = new Label("Filmes Favoritos");
        tituloFav.getStyleClass().add("label-subtitle");
        listaFavoritosPerfil = new VBox(10);

        Label top5Label = new Label("Meu Ranking — filmes avaliados");
        top5Label.getStyleClass().add("label-subtitle");
        listaRankingPerfil = new VBox(12);

        layout.getChildren().addAll(
                bannerContainer,
                cabecalho,
                painelPersonalizacao,
                tituloFav,
                listaFavoritosPerfil,
                top5Label,
                listaRankingPerfil
        );

        atualizarPerfil();

        ScrollPane rolagemCompleta = new ScrollPane(layout);
        rolagemCompleta.setFitToWidth(true);
        rolagemCompleta.setHbarPolicy(ScrollPane.ScrollBarPolicy.NEVER);
        return rolagemCompleta;
    }

    private VBox criarPainelPersonalizacao() {
        VBox box = new VBox(14);
        box.getStyleClass().add("card-filme");
        box.setPadding(new Insets(18));

        Label titulo = new Label("Personalização Visual (Cores, Gradientes e Sombras)");
        titulo.getStyleClass().add("label-subtitle");

        HBox linhaControles = new HBox(18);
        linhaControles.setAlignment(Pos.CENTER_LEFT);

        ColorPicker cpPrimaria = new ColorPicker(Color.web(usuarioLogado.getCorPrimaria()));
        ColorPicker cpSecundaria = new ColorPicker(Color.web(usuarioLogado.getCorSecundaria()));

        CheckBox chkGradiente = new CheckBox("Ativar Gradiente");
        chkGradiente.setSelected(usuarioLogado.isGradienteAtivo());
        chkGradiente.setTextFill(Color.web("#ffd0e8"));

        ComboBox<String> cbDirecao = new ComboBox<>();
        cbDirecao.getItems().addAll("VERTICAL", "HORIZONTAL", "DIAGONAL_CIMA", "DIAGONAL_BAIXO");
        cbDirecao.setValue(usuarioLogado.getDirecaoGradiente());

        ComboBox<String> cbSombra = new ComboBox<>();
        cbSombra.getItems().addAll("INFERIOR", "SUPERIOR", "ESQUERDA", "DIREITA", "NENHUMA");
        cbSombra.setValue(usuarioLogado.getTipoSombra());

        linhaControles.getChildren().addAll(
                new VBox(4, criarRotuloPesquisa("Cor Primária:"), cpPrimaria),
                new VBox(4, criarRotuloPesquisa("Cor Secundária:"), cpSecundaria),
                new VBox(4, criarRotuloPesquisa("Gradiente:"), chkGradiente),
                new VBox(4, criarRotuloPesquisa("Direção Gradiente:"), cbDirecao),
                new VBox(4, criarRotuloPesquisa("Sombra:"), cbSombra)
        );

        HBox previaBox = new HBox(12);
        previaBox.setAlignment(Pos.CENTER);
        previaBox.setPadding(new Insets(12));
        previaBox.setMinHeight(46);
        Label lblPrevia = new Label("Prévia ao vivo do estilo selecionado");
        lblPrevia.setStyle("-fx-text-fill: white; -fx-font-weight: bold;");
        previaBox.getChildren().add(lblPrevia);

        Runnable atualizarPrevia = () -> {
            String hex1 = toHex(cpPrimaria.getValue());
            String hex2 = toHex(cpSecundaria.getValue());
            String bg = chkGradiente.isSelected()
                    ? "linear-gradient(" + switch (cbDirecao.getValue()) {
                case "HORIZONTAL" -> "to right";
                case "DIAGONAL_CIMA" -> "to top right";
                case "DIAGONAL_BAIXO" -> "to bottom right";
                default -> "to bottom";
            } + ", " + hex2 + ", " + hex1 + ")"
                    : hex1;
            previaBox.setStyle("-fx-background-color: " + bg + "; -fx-background-radius: 10;");
        };
        atualizarPrevia.run();
        cpPrimaria.setOnAction(e -> atualizarPrevia.run());
        cpSecundaria.setOnAction(e -> atualizarPrevia.run());
        chkGradiente.setOnAction(e -> atualizarPrevia.run());
        cbDirecao.setOnAction(e -> atualizarPrevia.run());

        HBox botoes = new HBox(12);
        Button btnAplicar = new Button("Aplicar e Salvar Tema");
        estilizarBotaoPrincipal(btnAplicar);
        btnAplicar.setOnAction(e -> {
            usuarioLogado.setCorPrimaria(toHex(cpPrimaria.getValue()));
            usuarioLogado.setCorSecundaria(toHex(cpSecundaria.getValue()));
            usuarioLogado.setGradienteAtivo(chkGradiente.isSelected());
            usuarioLogado.setDirecaoGradiente(cbDirecao.getValue());
            usuarioLogado.setTipoSombra(cbSombra.getValue());
            GerenciadorDados.salvarUsuario(usuarioLogado);
            aplicarTemaDinamico();
            mostrarPagina("perfil");
            mostrarToast("Tema personalizado salvo");
        });

        Button btnRestaurar = new Button("Restaurar Padrão v10");
        btnRestaurar.getStyleClass().add("secondary-button");
        btnRestaurar.setOnAction(e -> {
            usuarioLogado.restaurarTemaPadrao();
            GerenciadorDados.salvarUsuario(usuarioLogado);
            aplicarTemaDinamico();
            mostrarPagina("perfil");
            mostrarToast("Tema padrão restaurado");
        });

        botoes.getChildren().addAll(btnAplicar, btnRestaurar);
        box.getChildren().addAll(titulo, linhaControles, previaBox, botoes);
        return box;
    }

    private String toHex(Color c) {
        return String.format("#%02x%02x%02x",
                (int) Math.round(c.getRed() * 255),
                (int) Math.round(c.getGreen() * 255),
                (int) Math.round(c.getBlue() * 255));
    }

    private void atualizarBanner() {
        if (bannerView == null) return;
        String caminho = usuarioLogado.getBannerPerfil();
        if (caminho != null && Files.exists(Path.of(caminho))) {
            try {
                bannerView.setImage(new Image(Path.of(caminho).toUri().toString()));
                return;
            } catch (Exception ignored) { }
        }
        bannerView.setImage(null);
    }

    private void escolherBannerPerfil() {
        FileChooser chooser = new FileChooser();
        chooser.setTitle("Escolher banner de perfil");
        chooser.getExtensionFilters().add(new FileChooser.ExtensionFilter("Imagens", "*.png", "*.jpg", "*.jpeg", "*.bmp"));
        File arquivo = chooser.showOpenDialog(primaryStage);
        if (arquivo == null) return;
        try {
            Path pasta = Path.of(System.getProperty("user.home"), ".filmeteca");
            Files.createDirectories(pasta);
            String extensao = arquivo.getName().contains(".") ? arquivo.getName().substring(arquivo.getName().lastIndexOf('.')) : ".png";
            Path destino = pasta.resolve("banner-perfil" + extensao.toLowerCase());
            Files.copy(arquivo.toPath(), destino, StandardCopyOption.REPLACE_EXISTING);
            usuarioLogado.setBannerPerfil(destino.toAbsolutePath().toString());
            GerenciadorDados.salvarUsuario(usuarioLogado);
            atualizarBanner();
            mostrarToast("Banner do perfil atualizado");
        } catch (Exception ex) {
            new Alert(Alert.AlertType.ERROR, "Não foi possível salvar o banner: " + ex.getMessage()).show();
        }
    }

    private void removerBannerPerfil() {
        usuarioLogado.setBannerPerfil(null);
        GerenciadorDados.salvarUsuario(usuarioLogado);
        atualizarBanner();
        mostrarToast("Banner removido");
    }

    private void atualizarAvatar() {
        if (avatarView == null) return;
        String caminho = usuarioLogado.getFotoPerfil();
        if (caminho != null && Files.exists(Path.of(caminho))) {
            try {
                avatarView.setImage(new Image(Path.of(caminho).toUri().toString(), 112, 112, false, true));
                return;
            } catch (Exception ignored) { }
        }
        try {
            avatarView.setImage(new Image(getClass().getResourceAsStream("/view/app-icon.png")));
        } catch (Exception ignored) { }
    }

    private void escolherFotoPerfil() {
        FileChooser chooser = new FileChooser();
        chooser.setTitle("Escolher foto de perfil");
        chooser.getExtensionFilters().add(new FileChooser.ExtensionFilter("Imagens", "*.png", "*.jpg", "*.jpeg", "*.gif", "*.bmp"));
        File arquivo = chooser.showOpenDialog(primaryStage);
        if (arquivo == null) return;
        try {
            Path pasta = Path.of(System.getProperty("user.home"), ".filmeteca");
            Files.createDirectories(pasta);
            String extensao = arquivo.getName().contains(".") ? arquivo.getName().substring(arquivo.getName().lastIndexOf('.')) : ".png";
            Path destino = pasta.resolve("foto-perfil" + extensao.toLowerCase());
            Files.copy(arquivo.toPath(), destino, StandardCopyOption.REPLACE_EXISTING);
            usuarioLogado.setFotoPerfil(destino.toAbsolutePath().toString());
            GerenciadorDados.salvarUsuario(usuarioLogado);
            atualizarAvatar();
            mostrarToast("Foto de perfil atualizada");
        } catch (Exception ex) {
            new Alert(Alert.AlertType.ERROR, "Não foi possível salvar a imagem: " + ex.getMessage()).show();
        }
    }

    private void atualizarPerfil() {
        if (usuarioLogado == null) return;

        if (statsLabel != null) {
            statsLabel.setText("Filmes Assistidos: " + usuarioLogado.getTotalVistos() +
                    "  •  Gênero Preferido: " + usuarioLogado.getGeneroPredominante() +
                    "  •  Favoritos: " + usuarioLogado.getFilmesFavoritos().size());
        }

        if (listaFavoritosPerfil != null) {
            listaFavoritosPerfil.getChildren().clear();
            List<Filme> favoritos = usuarioLogado.getFilmesFavoritos();
            if (favoritos.isEmpty()) {
                Label semFav = new Label("Nenhum filme marcado como favorito ainda. Clique em '☆ Favoritar' nos cards da aba Explorar.");
                semFav.getStyleClass().add("label-info");
                listaFavoritosPerfil.getChildren().add(semFav);
            } else {
                FlowPane flowFav = new FlowPane(12, 12);
                for (Filme fav : favoritos) {
                    HBox chip = new HBox(10);
                    chip.setAlignment(Pos.CENTER_LEFT);
                    chip.getStyleClass().add("ranking-item");
                    chip.setPadding(new Insets(8, 12, 8, 12));
                    ImageView p = new ImageView();
                    p.setFitWidth(42);
                    p.setFitHeight(63);
                    p.setPreserveRatio(true);
                    if (fav.getPosterUrl() != null) p.setImage(new Image(fav.getPosterUrl(), 42, 63, true, true, true));
                    VBox info = new VBox(3);
                    Label t = new Label("★ " + fav.getTitulo() + " (" + fav.getAno() + ")");
                    t.getStyleClass().add("label-bold");
                    Label g = new Label(String.join(", ", fav.getGeneros()));
                    g.getStyleClass().add("label-info");
                    g.setStyle("-fx-font-size: 11px;");
                    info.getChildren().addAll(t, g);
                    chip.getChildren().addAll(p, info);
                    flowFav.getChildren().add(chip);
                }
                listaFavoritosPerfil.getChildren().add(flowFav);
            }
        }

        if (listaRankingPerfil != null) {
            listaRankingPerfil.getChildren().clear();
            List<Filme> ranking = usuarioLogado.getRankingCompleto();
            if (ranking.isEmpty()) {
                Label vazio = new Label("Nenhum filme avaliado ainda. Avalie um filme na aba Explorar para incluí-lo aqui.");
                vazio.getStyleClass().add("label-info");
                listaRankingPerfil.getChildren().add(vazio);
                return;
            }
            for (int i = 0; i < ranking.size(); i++) {
                Filme filme = ranking.get(i);
                HBox item = new HBox(14);
                item.setAlignment(Pos.CENTER_LEFT);
                item.getStyleClass().add("ranking-item");
                item.setEffect(criarSombraDinamica());

                Label posicao = new Label((i + 1) + "º");
                posicao.getStyleClass().add("ranking-position");
                posicao.setStyle("-fx-text-fill: " + usuarioLogado.getCorSecundaria() + ";");

                ImageView poster = new ImageView();
                poster.setFitWidth(76);
                poster.setFitHeight(114);
                poster.setPreserveRatio(true);
                if (filme.getPosterUrl() != null && !filme.getPosterUrl().isBlank())
                    poster.setImage(new Image(filme.getPosterUrl(), 76, 114, true, true, true));

                VBox detalhes = new VBox(5);
                String prefixoFav = filme.isFavorito() ? "★ " : "";
                Label nome = new Label(prefixoFav + filme.getTitulo() + " (" + filme.getAno() + ")");
                nome.getStyleClass().add("label-subtitle");

                Label nota = new Label("Sua nota: " + filme.getNotaUsuario() + "  •  Pontuação Elo: " + filme.getEloScore());
                nota.getStyleClass().add("label-bold");

                Label comentario = new Label(filme.getComentario() == null || filme.getComentario().isBlank()
                        ? "Sem comentário" : filme.getComentario());
                comentario.setWrapText(true);
                comentario.getStyleClass().add("label-info");

                detalhes.getChildren().addAll(nome, nota, comentario);
                HBox.setHgrow(detalhes, Priority.ALWAYS);

                Button excluir = new Button("Excluir");
                excluir.getStyleClass().add("delete-button");
                excluir.setOnAction(e -> {
                    Alert confirmacao = new Alert(Alert.AlertType.CONFIRMATION,
                            "Deseja realmente remover este filme?",
                            ButtonType.CANCEL,
                            ButtonType.OK
                    );
                    confirmacao.showAndWait().ifPresent(resposta -> {
                        if (resposta == ButtonType.OK) {
                            usuarioLogado.removerFilme(filme);
                            GerenciadorDados.salvarUsuario(usuarioLogado);
                            atualizarPerfil();
                            mostrarToast("Filme removido do perfil");
                        }
                    });
                });

                item.getChildren().addAll(posicao, poster, detalhes, excluir);
                listaRankingPerfil.getChildren().add(item);
            }
        }
    }

    private void exportarPerfilPng() {
        FileChooser chooser = new FileChooser();
        chooser.setTitle("Exportar Perfil como PNG");
        chooser.setInitialFileName("filmeteca-perfil-" + usuarioLogado.getNome().toLowerCase().replaceAll("\\s+", "-") + ".png");
        chooser.getExtensionFilters().add(new FileChooser.ExtensionFilter("Imagem PNG", "*.png"));
        File destino = chooser.showSaveDialog(primaryStage);
        if (destino == null) return;

        try {
            VBox cardExport = construirCardExportacaoPng();
            Scene tempScene = new Scene(cardExport);
            tempScene.getStylesheets().add(getClass().getResource("/view/style.css").toExternalForm());
            cardExport.applyCss();
            cardExport.layout();

            SnapshotParameters params = new SnapshotParameters();
            params.setFill(Color.web("#120f16"));
            params.setTransform(Transform.scale(2.0, 2.0));

            WritableImage snapshot = cardExport.snapshot(params, null);
            salvarWritableImageComoPng(snapshot, destino);
            mostrarToast("Perfil exportado em PNG com sucesso");
        } catch (Exception ex) {
            ex.printStackTrace();
            new Alert(Alert.AlertType.ERROR, "Erro ao exportar PNG: " + ex.getMessage()).show();
        }
    }

    private VBox construirCardExportacaoPng() {
        VBox rootExport = new VBox(18);
        rootExport.setPrefWidth(820);
        rootExport.setPadding(new Insets(28));
        rootExport.setStyle("-fx-background-color: #120f16; -fx-border-color: " + usuarioLogado.getCorPrimaria()
                + "; -fx-border-width: 2; -fx-border-radius: 16; -fx-background-radius: 16;");

        HBox faixaMarca = new HBox(10);
        faixaMarca.setAlignment(Pos.CENTER_LEFT);
        faixaMarca.setPadding(new Insets(12, 18, 12, 18));
        faixaMarca.setStyle("-fx-background-color: " + getEstiloFundoDestaque() + "; -fx-background-radius: 12;");
        Label brand = new Label("FILMETECA • PERFIL CINEMATOGRÁFICO");
        brand.setStyle("-fx-text-fill: white; -fx-font-weight: bold; -fx-font-size: 14px;");
        faixaMarca.getChildren().add(brand);

        HBox idBox = new HBox(18);
        idBox.setAlignment(Pos.CENTER_LEFT);
        ImageView av = new ImageView();
        av.setFitWidth(96);
        av.setFitHeight(96);
        av.setPreserveRatio(false);
        av.setClip(new Circle(48, 48, 48));
        if (avatarView != null && avatarView.getImage() != null) av.setImage(avatarView.getImage());

        VBox dadosUser = new VBox(6);
        Label nome = new Label(usuarioLogado.getNome() + ", " + usuarioLogado.getIdade() + " anos");
        nome.setStyle("-fx-text-fill: #f3f5fb; -fx-font-size: 24px; -fx-font-weight: bold;");
        Label resumo = new Label("Assistidos: " + usuarioLogado.getTotalVistos()
                + "  |  Gênero Predominante: " + usuarioLogado.getGeneroPredominante()
                + "  |  Favoritos: " + usuarioLogado.getFilmesFavoritos().size());
        resumo.setStyle("-fx-text-fill: #ffd0e8; -fx-font-size: 13px; -fx-font-weight: bold;");
        dadosUser.getChildren().addAll(nome, resumo);
        idBox.getChildren().addAll(av, dadosUser);

        VBox boxTop = new VBox(8);
        boxTop.setPadding(new Insets(14));
        boxTop.setStyle("-fx-background-color: #1d1720; -fx-border-color: #493047; -fx-border-radius: 10; -fx-background-radius: 10;");
        Label topTitulo = new Label("Top Filmes Avaliados");
        topTitulo.setStyle("-fx-text-fill: " + usuarioLogado.getCorSecundaria() + "; -fx-font-weight: bold; -fx-font-size: 15px;");
        boxTop.getChildren().add(topTitulo);

        List<Filme> ranking = usuarioLogado.getRankingCompleto();
        if (ranking.isEmpty()) {
            Label sem = new Label("Nenhum filme avaliado ainda.");
            sem.setStyle("-fx-text-fill: #c2cada;");
            boxTop.getChildren().add(sem);
        } else {
            int max = Math.min(5, ranking.size());
            for (int i = 0; i < max; i++) {
                Filme f = ranking.get(i);
                Label item = new Label((i + 1) + "º  " + (f.isFavorito() ? "★ " : "") + f.getTitulo()
                        + " (" + f.getAno() + ") — Nota: " + f.getNotaUsuario() + " | Elo: " + f.getEloScore());
                item.setStyle("-fx-text-fill: #f3f5fb; -fx-font-size: 13px;");
                boxTop.getChildren().add(item);
            }
        }

        rootExport.getChildren().addAll(faixaMarca, idBox, boxTop);
        return rootExport;
    }

    private void salvarWritableImageComoPng(WritableImage image, File file) throws Exception {
        int width = (int) image.getWidth();
        int height = (int) image.getHeight();
        PixelReader reader = image.getPixelReader();

        byte[] rawRows = new byte[height * (1 + width * 4)];
        int pos = 0;
        for (int y = 0; y < height; y++) {
            rawRows[pos++] = 0;
            for (int x = 0; x < width; x++) {
                int argb = reader.getArgb(x, y);
                rawRows[pos++] = (byte) ((argb >> 16) & 0xFF);
                rawRows[pos++] = (byte) ((argb >> 8) & 0xFF);
                rawRows[pos++] = (byte) (argb & 0xFF);
                rawRows[pos++] = (byte) ((argb >> 24) & 0xFF);
            }
        }

        ByteArrayOutputStream compressed = new ByteArrayOutputStream();
        try (DeflaterOutputStream deflater = new DeflaterOutputStream(compressed)) {
            deflater.write(rawRows);
        }

        try (DataOutputStream out = new DataOutputStream(new FileOutputStream(file))) {
            out.write(new byte[]{(byte) 137, 80, 78, 71, 13, 10, 26, 10});

            ByteArrayOutputStream ihdr = new ByteArrayOutputStream();
            DataOutputStream ihdrOut = new DataOutputStream(ihdr);
            ihdrOut.writeInt(width);
            ihdrOut.writeInt(height);
            ihdrOut.writeByte(8);
            ihdrOut.writeByte(6);
            ihdrOut.writeByte(0);
            ihdrOut.writeByte(0);
            ihdrOut.writeByte(0);
            escreverChunkPng(out, "IHDR", ihdr.toByteArray());

            escreverChunkPng(out, "IDAT", compressed.toByteArray());
            escreverChunkPng(out, "IEND", new byte[0]);
        }
    }

    private void escreverChunkPng(DataOutputStream out, String type, byte[] data) throws Exception {
        out.writeInt(data.length);
        byte[] typeBytes = type.getBytes("US-ASCII");
        out.write(typeBytes);
        out.write(data);
        CRC32 crc = new CRC32();
        crc.update(typeBytes);
        crc.update(data);
        out.writeInt((int) crc.getValue());
    }

    public static void main(String[] args) {
        launch(args);
    }
}