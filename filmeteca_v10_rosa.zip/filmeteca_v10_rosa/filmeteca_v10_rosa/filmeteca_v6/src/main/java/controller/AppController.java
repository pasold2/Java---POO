package controller;

import model.Filme;
import model.GerenciadorDados;
import model.SistemaRanking;
import model.Usuario;

public class AppController {
    private Usuario usuarioLogado;

    public AppController(Usuario usuarioLogado) {
        this.usuarioLogado = usuarioLogado;
    }

    public Usuario getUsuarioLogado() {
        return usuarioLogado;
    }

    public void setUsuarioLogado(Usuario usuarioLogado) {
        this.usuarioLogado = usuarioLogado;
    }

    public void registrarVitoria(Filme vencedor, Filme perdedor) {
        if (vencedor != null && perdedor != null) {
            SistemaRanking.processarConfronto(vencedor, perdedor);
            if (usuarioLogado != null) {
                GerenciadorDados.salvarUsuario(usuarioLogado);
            }
        }
    }
}