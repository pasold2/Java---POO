package model;

import org.json.JSONArray;
import org.json.JSONObject;

import java.net.URI;
import java.net.URLEncoder;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.text.Normalizer;
import java.util.*;

public class TmdbApi {
    private static final String API_KEY = "fa9ceb38de75bbbca4f4a5b84e680d9e";
    private static final String BASE_URL = "https://api.themoviedb.org/3";
    private static final String IMAGE_BASE_URL = "https://image.tmdb.org/t/p/w200";

    private static final Map<Integer, String> MAPA_GENEROS = Map.ofEntries(
            Map.entry(28, "Ação"), Map.entry(12, "Aventura"), Map.entry(16, "Animação"),
            Map.entry(35, "Comédia"), Map.entry(80, "Crime"), Map.entry(99, "Documentário"),
            Map.entry(18, "Drama"), Map.entry(10751, "Família"), Map.entry(14, "Fantasia"),
            Map.entry(36, "História"), Map.entry(27, "Terror"), Map.entry(10402, "Música"),
            Map.entry(9648, "Mistério"), Map.entry(10749, "Romance"), Map.entry(878, "Ficção científica"),
            Map.entry(10770, "Cinema TV"), Map.entry(53, "Thriller"), Map.entry(10752, "Guerra"),
            Map.entry(37, "Faroeste")
    );

    private static final Map<String, Integer> GENERO_PARA_ID = new HashMap<>();
    static {
        for (Map.Entry<Integer, String> entry : MAPA_GENEROS.entrySet()) {
            GENERO_PARA_ID.put(entry.getValue().toLowerCase(), entry.getKey());
        }
    }

    private static final Map<String, String> MAPA_PAISES = Map.ofEntries(
            Map.entry("brasil", "BR"), Map.entry("brasileiro", "BR"), Map.entry("brasileira", "BR"), Map.entry("brazil", "BR"), Map.entry("br", "BR"),
            Map.entry("estados unidos", "US"), Map.entry("americano", "US"), Map.entry("americana", "US"), Map.entry("eua", "US"), Map.entry("usa", "US"), Map.entry("united states", "US"),
            Map.entry("italia", "IT"), Map.entry("italy", "IT"), Map.entry("franca", "FR"), Map.entry("frances", "FR"), Map.entry("francesa", "FR"), Map.entry("france", "FR"),
            Map.entry("alemanha", "DE"), Map.entry("alemao", "DE"), Map.entry("alema", "DE"), Map.entry("germany", "DE"), Map.entry("japao", "JP"), Map.entry("japones", "JP"), Map.entry("japonesa", "JP"), Map.entry("japan", "JP"),
            Map.entry("reino unido", "GB"), Map.entry("inglaterra", "GB"), Map.entry("united kingdom", "GB"),
            Map.entry("espanha", "ES"), Map.entry("spain", "ES"), Map.entry("argentina", "AR"),
            Map.entry("mexico", "MX"), Map.entry("canada", "CA"), Map.entry("coreia do sul", "KR"), Map.entry("coreano", "KR"), Map.entry("coreana", "KR"),
            Map.entry("south korea", "KR"), Map.entry("india", "IN"), Map.entry("china", "CN"),
            Map.entry("russia", "RU"), Map.entry("australia", "AU"),
            Map.entry("portugal", "PT"), Map.entry("suecia", "SE"), Map.entry("sweden", "SE"),
            Map.entry("dinamarca", "DK"), Map.entry("denmark", "DK"), Map.entry("irlanda", "IE"),
            Map.entry("ireland", "IE"), Map.entry("polonia", "PL"), Map.entry("poland", "PL"),
            Map.entry("turquia", "TR"), Map.entry("turkey", "TR"), Map.entry("tailandia", "TH"),
            Map.entry("thailand", "TH"), Map.entry("taiwan", "TW"), Map.entry("hong kong", "HK")
    );

    public static String normalizar(String texto) {
        if (texto == null) return "";
        return Normalizer.normalize(texto, Normalizer.Form.NFD)
                .replaceAll("\\p{M}", "")
                .toLowerCase()
                .trim();
    }

    public static List<Filme> buscarFilmes(String query, String filtroGenero, String filtroAno,
                                           String filtroDiretor, String filtroAtor, String filtroPais, int page) throws Exception {
        HttpClient client = HttpClient.newHttpClient();
        String url;

        String buscaLimpa = normalizar(query);
        String diretorLimpo = normalizar(filtroDiretor);
        String atorLimpo = normalizar(filtroAtor);

        // 1. Se digitou título, usa /search/movie
        if (!buscaLimpa.isEmpty()) {
            String encodedQuery = URLEncoder.encode(buscaLimpa, StandardCharsets.UTF_8);
            url = BASE_URL + "/search/movie?api_key=" + API_KEY + "&query=" + encodedQuery + "&language=pt-BR&page=" + page;
        }
        // 2. Se especificou Diretor ou Ator (sem título), busca a pessoa primeiro
        else if (!diretorLimpo.isEmpty() || !atorLimpo.isEmpty()) {
            String pessoaTermo = !diretorLimpo.isEmpty() ? diretorLimpo : atorLimpo;
            String encodedPessoa = URLEncoder.encode(pessoaTermo, StandardCharsets.UTF_8);
            String searchPersonUrl = BASE_URL + "/search/person?api_key=" + API_KEY + "&query=" + encodedPessoa + "&language=pt-BR";

            HttpRequest pReq = HttpRequest.newBuilder().uri(URI.create(searchPersonUrl)).GET().build();
            HttpResponse<String> pResp = client.send(pReq, HttpResponse.BodyHandlers.ofString());
            JSONObject pObj = new JSONObject(pResp.body());

            int personId = -1;
            if (pObj.has("results") && pObj.getJSONArray("results").length() > 0) {
                personId = pObj.getJSONArray("results").getJSONObject(0).getInt("id");
            }

            if (personId != -1) {
                url = BASE_URL + "/person/" + personId + "/movie_credits?api_key=" + API_KEY + "&language=pt-BR";
            } else {
                url = BASE_URL + "/discover/movie?api_key=" + API_KEY + "&language=pt-BR&sort_by=popularity.desc&page=" + page;
            }
        }
        // 3. Busca geral/por ano/gênero/país com /discover/movie
        else {
            StringBuilder sb = new StringBuilder(BASE_URL + "/discover/movie?api_key=" + API_KEY + "&language=pt-BR&sort_by=popularity.desc&page=" + page);
            if (filtroAno != null && !filtroAno.isBlank()) {
                sb.append("&primary_release_year=").append(filtroAno.trim());
            }
            if (filtroGenero != null && !filtroGenero.equals("Todos")) {
                Integer genId = GENERO_PARA_ID.get(filtroGenero.toLowerCase());
                if (genId != null) {
                    sb.append("&with_genres=").append(genId);
                }
            }
            if (filtroPais != null && !filtroPais.isBlank()) {
                String paisNorm = normalizar(filtroPais);
                String codigoPais = MAPA_PAISES.get(paisNorm);
                if (codigoPais == null && paisNorm.matches("[a-z]{2}")) {
                    codigoPais = paisNorm.toUpperCase(Locale.ROOT);
                }
                if (codigoPais != null) {
                    sb.append("&with_origin_country=").append(codigoPais);
                }
            }
            url = sb.toString();
        }

        HttpRequest request = HttpRequest.newBuilder().uri(URI.create(url)).GET().build();
        HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());

        List<Filme> resultados = new ArrayList<>();
        JSONObject jsonObject = new JSONObject(response.body());

        JSONArray resultsArray = null;
        if (jsonObject.has("results")) {
            resultsArray = jsonObject.getJSONArray("results");
        } else if (jsonObject.has("cast") || jsonObject.has("crew")) {
            resultsArray = jsonObject.has("cast") ? jsonObject.getJSONArray("cast") : jsonObject.getJSONArray("crew");
        }

        if (resultsArray == null) return resultados;

        for (int i = 0; i < resultsArray.length(); i++) {
            JSONObject fJson = resultsArray.getJSONObject(i);
            int id = fJson.getInt("id");
            String titulo = fJson.optString("title", fJson.optString("original_title", "Sem Título"));
            String sinopse = fJson.optString("overview", "Sem sinopse disponível.");
            if (sinopse.trim().isEmpty()) sinopse = "Sem sinopse disponível.";
            double nota = fJson.optDouble("vote_average", 0.0);

            String posterPath = fJson.optString("poster_path", null);
            String posterUrl = (posterPath != null && !posterPath.equals("null") && !posterPath.isEmpty())
                    ? IMAGE_BASE_URL + posterPath : null;

            String releaseDate = fJson.optString("release_date", "");
            String ano = (!releaseDate.isEmpty() && releaseDate.contains("-")) ? releaseDate.split("-")[0] : "N/I";

            List<String> generos = new ArrayList<>();
            JSONArray genreIds = fJson.optJSONArray("genre_ids");
            if (genreIds != null) {
                for (int j = 0; j < genreIds.length(); j++) {
                    generos.add(MAPA_GENEROS.getOrDefault(genreIds.getInt(j), "Geral"));
                }
            }
            if (generos.isEmpty()) generos.add("Geral");

            String diretor = "Desconhecido";
            List<String> elenco = new ArrayList<>();
            List<String> paises = new ArrayList<>();
            List<String> codigosPaises = new ArrayList<>();

            try {
                String detailUrl = BASE_URL + "/movie/" + id + "?api_key=" + API_KEY + "&language=pt-BR&append_to_response=credits";
                HttpRequest detailReq = HttpRequest.newBuilder().uri(URI.create(detailUrl)).GET().build();
                HttpResponse<String> detailResp = client.send(detailReq, HttpResponse.BodyHandlers.ofString());
                JSONObject detailObj = new JSONObject(detailResp.body());

                if (detailObj.has("production_countries")) {
                    JSONArray cArr = detailObj.getJSONArray("production_countries");
                    for (int k = 0; k < cArr.length(); k++) {
                        JSONObject paisJson = cArr.getJSONObject(k);
                        paises.add(paisJson.optString("name", ""));
                        String codigo = paisJson.optString("iso_3166_1", "");
                        if (!codigo.isBlank()) codigosPaises.add(codigo.toUpperCase(Locale.ROOT));
                    }
                }

                if (detailObj.has("credits")) {
                    JSONObject credits = detailObj.getJSONObject("credits");
                    if (credits.has("crew")) {
                        JSONArray crew = credits.getJSONArray("crew");
                        for (int c = 0; c < crew.length(); c++) {
                            JSONObject member = crew.getJSONObject(c);
                            if ("Director".equalsIgnoreCase(member.optString("job"))) {
                                diretor = member.optString("name", "Desconhecido");
                                break;
                            }
                        }
                    }

                    if (credits.has("cast")) {
                        JSONArray cast = credits.getJSONArray("cast");
                        int maxCast = Math.min(cast.length(), 5);
                        for (int a = 0; a < maxCast; a++) {
                            elenco.add(cast.getJSONObject(a).optString("name", ""));
                        }
                    }
                }
            } catch (Exception e) {
                // Silencioso
            }

            Filme filme = new Filme(id, titulo, sinopse, nota, generos, posterUrl, ano, diretor, elenco, paises);

            boolean passaAno = filtroAno == null || filtroAno.isBlank() || filme.getAno().equalsIgnoreCase(filtroAno.trim());
            boolean passaGenero = filtroGenero == null || filtroGenero.equals("Todos") || filme.getGeneros().contains(filtroGenero);
            boolean passaDiretor = filtroDiretor == null || filtroDiretor.isBlank() || normalizar(filme.getDiretor()).contains(normalizar(filtroDiretor));
            boolean passaAtor = filtroAtor == null || filtroAtor.isBlank() || filme.getElenco().stream()
                    .anyMatch(a -> normalizar(a).contains(normalizar(filtroAtor)));
            boolean passaPais = true;
            if (filtroPais != null && !filtroPais.isBlank()) {
                String paisNorm = normalizar(filtroPais);
                String codigoPais = MAPA_PAISES.get(paisNorm);
                if (codigoPais == null && paisNorm.matches("[a-z]{2}")) codigoPais = paisNorm.toUpperCase(Locale.ROOT);
                if (codigoPais != null) {
                    passaPais = codigosPaises.contains(codigoPais);
                } else {
                    passaPais = filme.getPaises().stream().anyMatch(p -> normalizar(p).contains(paisNorm));
                }
            }

            if (passaAno && passaGenero && passaDiretor && passaAtor && passaPais) {
                resultados.add(filme);
            }
        }

        return resultados;
    }

    public static List<Filme> buscarCandidatosRecomendacao(Usuario usuario) throws Exception {
        Map<Integer, Filme> pool = new LinkedHashMap<>();
        for (int p = 1; p <= 2; p++) {
            for (Filme f : buscarFilmes("", "Todos", "", "", "", "", p)) {
                pool.putIfAbsent(f.getId(), f);
            }
        }
        if (usuario != null) {
            int count = 0;
            for (String gen : usuario.getEstatisticasGeneros().keySet()) {
                if (GENERO_PARA_ID.containsKey(gen.toLowerCase())) {
                    for (Filme f : buscarFilmes("", gen, "", "", "", "", 1)) {
                        pool.putIfAbsent(f.getId(), f);
                    }
                    count++;
                    if (count >= 2) break;
                }
            }
        }
        return new ArrayList<>(pool.values());
    }
}