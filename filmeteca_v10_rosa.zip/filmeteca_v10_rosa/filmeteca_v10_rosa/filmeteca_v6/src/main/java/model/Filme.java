package model;

import java.io.Serializable;
import java.util.List;
import java.util.Objects;

public class Filme implements Serializable {
    private static final long serialVersionUID = 1L;

    private int id;
    private String titulo;
    private String sinopse;
    private double notaGeral;
    private List<String> generos;
    private String posterUrl;
    private String ano;
    private String diretor;
    private List<String> elenco;
    private List<String> paises;

    private boolean visto;
    private boolean favorito;
    private Double notaUsuario;
    private String comentario;
    private double eloScore = 1400.0;

    public Filme(int id, String titulo, String sinopse, double notaGeral, List<String> generos,
                 String posterUrl, String ano, String diretor, List<String> elenco, List<String> paises) {
        this.id = id;
        this.titulo = titulo;
        this.sinopse = sinopse;
        this.notaGeral = notaGeral;
        this.generos = generos;
        this.posterUrl = posterUrl;
        this.ano = ano;
        this.diretor = diretor;
        this.elenco = elenco;
        this.paises = paises;
        this.visto = false;
        this.favorito = false;
    }

    public void avaliarEComentar(double nota, String comentario) {
        this.notaUsuario = nota;
        this.comentario = comentario;
        this.visto = true;
    }

    public int getId() { return id; }
    public String getTitulo() { return titulo; }
    public String getSinopse() { return sinopse; }
    public double getNotaGeral() { return notaGeral; }
    public List<String> getGeneros() { return generos; }
    public String getPosterUrl() { return posterUrl; }
    public String getAno() { return ano; }
    public String getDiretor() { return diretor; }
    public List<String> getElenco() { return elenco; }
    public List<String> getPaises() { return paises; }

    public boolean isVisto() { return visto; }
    public void setVisto(boolean visto) { this.visto = visto; }

    public boolean isFavorito() { return favorito; }
    public void setFavorito(boolean favorito) { this.favorito = favorito; }

    public Double getNotaUsuario() { return notaUsuario; }
    public void setNotaUsuario(Double notaUsuario) { this.notaUsuario = notaUsuario; }

    public String getComentario() { return comentario; }
    public void setComentario(String comentario) { this.comentario = comentario; }

    public double getEloScore() { return eloScore; }
    public void setEloScore(double eloScore) { this.eloScore = eloScore; }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Filme filme = (Filme) o;
        return id == filme.id;
    }

    @Override
    public int hashCode() {
        return Objects.hash(id);
    }
}