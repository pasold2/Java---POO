package model;

import java.io.*;
import java.nio.file.Files;
import java.nio.file.Path;

public class GerenciadorDados {
    private static final Path CAMINHO_ARQUIVO = Path.of(System.getProperty("user.home"), ".filmeteca", "dados_usuario.dat");

    public static void salvarUsuario(Usuario usuario) {
        try {
            Files.createDirectories(CAMINHO_ARQUIVO.getParent());
            try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(CAMINHO_ARQUIVO.toFile()))) {
                oos.writeObject(usuario);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static Usuario carregarUsuario() {
        if (!Files.exists(CAMINHO_ARQUIVO)) {
            return null;
        }
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(CAMINHO_ARQUIVO.toFile()))) {
            return (Usuario) ois.readObject();
        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
            return null;
        }
    }
}
