package model;

public class SistemaRanking {
    private static final double K = 32.0;

    public static void processarConfronto(Filme vencedor, Filme perdedor) {
        double rVencedor = vencedor.getEloScore();
        double rPerdedor = perdedor.getEloScore();

        double e1 = 1.0 / (1.0 + Math.pow(10.0, (rPerdedor - rVencedor) / 400.0));
        double e2 = 1.0 / (1.0 + Math.pow(10.0, (rVencedor - rPerdedor) / 400.0));

        vencedor.setEloScore(rVencedor + K * (1.0 - e1));
        perdedor.setEloScore(rPerdedor + K * (0.0 - e2));
    }
}