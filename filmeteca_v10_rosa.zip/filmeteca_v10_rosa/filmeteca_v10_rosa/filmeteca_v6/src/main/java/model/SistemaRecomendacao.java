package model;

import java.util.*;
import java.util.stream.Collectors;

/**
 * Motor de Recomendacao da Filmeteca v11.
 * Constroi uma Matriz Filme x Caracteristicas (generos, diretor, elenco, paises e decada),
 * aplica Fatoracao de Matrizes (SVD Truncado via Iteracao de Potencia Deflacionada)
 * para extrair fatores latentes e calcula a Similaridade de Cosseno ponderada pelas
 * avaliacoes do usuario, aplicando diversificacao MMR (Maximal Marginal Relevance).
 */
public class SistemaRecomendacao {

    public static class ResultadoRecomendacao {
        private final Filme filme;
        private final double pontuacao;
        private final String justificativa;
        private final boolean modoFallback;

        public ResultadoRecomendacao(Filme filme, double pontuacao, String justificativa, boolean modoFallback) {
            this.filme = filme;
            this.pontuacao = pontuacao;
            this.justificativa = justificativa;
            this.modoFallback = modoFallback;
        }

        public Filme getFilme() { return filme; }
        public double getPontuacao() { return pontuacao; }
        public String getJustificativa() { return justificativa; }
        public boolean isModoFallback() { return modoFallback; }
    }

    public static List<ResultadoRecomendacao> recomendar(Usuario usuario, List<Filme> candidatos, int limite) {
        if (usuario == null || candidatos == null || candidatos.isEmpty()) {
            return Collections.emptyList();
        }

        Set<Integer> idsAssistidos = usuario.getFilmesVistos().stream()
                .map(Filme::getId)
                .collect(Collectors.toSet());

        Map<Integer, Filme> candidatosUnicos = new LinkedHashMap<>();
        for (Filme c : candidatos) {
            if (c != null && !idsAssistidos.contains(c.getId())) {
                candidatosUnicos.putIfAbsent(c.getId(), c);
            }
        }
        List<Filme> poolCandidatos = new ArrayList<>(candidatosUnicos.values());
        if (poolCandidatos.isEmpty()) return Collections.emptyList();

        List<Filme> historico = usuario.getFilmesVistos();

        // Fallback elegante para historico muito pequeno
        if (historico.size() < 2) {
            return gerarFallback(poolCandidatos, limite,
                    "Histórico inicial reduzido — exibindo destaques bem avaliados do catálogo.");
        }

        // 1. Vocabulario da Matriz Filme x Caracteristicas
        Map<String, Integer> vocabulario = new LinkedHashMap<>();
        List<Filme> todosFilmes = new ArrayList<>(historico);
        todosFilmes.addAll(poolCandidatos);

        for (Filme f : todosFilmes) {
            for (String feat : extrairPesosCaracteristicas(f).keySet()) {
                vocabulario.putIfAbsent(feat, vocabulario.size());
            }
        }

        int numFilmes = todosFilmes.size();
        int numFeatures = vocabulario.size();
        if (numFeatures == 0) {
            return gerarFallback(poolCandidatos, limite,
                    "Metadados insuficientes para vetorização — exibindo sugestões populares.");
        }

        double[][] matrizM = new double[numFilmes][numFeatures];
        for (int i = 0; i < numFilmes; i++) {
            Map<String, Double> pesos = extrairPesosCaracteristicas(todosFilmes.get(i));
            for (Map.Entry<String, Double> e : pesos.entrySet()) {
                Integer idx = vocabulario.get(e.getKey());
                if (idx != null) {
                    matrizM[i][idx] = e.getValue();
                }
            }
            normalizarL2(matrizM[i]);
        }

        // 2. Fatoracao de Matrizes (SVD Truncado)
        int k = Math.min(12, Math.min(numFilmes, numFeatures));
        double[][] vetoresLatentes = fatorarSvdTruncado(matrizM, k);

        // 3. Vetor de preferencia do usuario no espaco latente
        // Notas > 5.5 contribuem positivamente, < 5.5 negativamente; filmes sem nota recebem peso neutro positivo (0.35)
        double[] perfilLatente = new double[k];
        double somaPesosAbs = 0.0;

        for (int i = 0; i < historico.size(); i++) {
            Filme f = historico.get(i);
            double peso = (f.getNotaUsuario() != null)
                    ? (f.getNotaUsuario() - 5.5) / 4.5
                    : 0.35;
            if (f.isFavorito()) {
                peso += 0.30;
            }
            for (int d = 0; d < k; d++) {
                perfilLatente[d] += peso * vetoresLatentes[i][d];
            }
            somaPesosAbs += Math.abs(peso);
        }

        if (norma(perfilLatente) < 1e-9 || somaPesosAbs < 1e-9) {
            Arrays.fill(perfilLatente, 0.0);
            for (int i = 0; i < historico.size(); i++) {
                for (int d = 0; d < k; d++) {
                    perfilLatente[d] += vetoresLatentes[i][d];
                }
            }
        }

        if (norma(perfilLatente) < 1e-9) {
            return gerarFallback(poolCandidatos, limite,
                    "Perfil ainda neutro — exibindo filmes com melhor recepção crítica.");
        }

        // 4. Similaridade de Cosseno no espaco latente + qualidade TMDB
        List<ResultadoRecomendacao> avaliados = new ArrayList<>();
        int offsetCandidatos = historico.size();

        for (int c = 0; c < poolCandidatos.size(); c++) {
            Filme cand = poolCandidatos.get(c);
            double[] vecCand = vetoresLatentes[offsetCandidatos + c];
            double simLatente = similaridadeCosseno(perfilLatente, vecCand);
            double simNormalizada = (simLatente + 1.0) / 2.0;
            double qualidadeTmdb = Math.min(10.0, Math.max(0.0, cand.getNotaGeral())) / 10.0;

            double scoreFinal = (0.75 * simNormalizada) + (0.25 * qualidadeTmdb);
            String justificativa = construirJustificativa(usuario, cand, simLatente);
            avaliados.add(new ResultadoRecomendacao(cand, scoreFinal, justificativa, false));
        }

        avaliados.sort((a, b) -> Double.compare(b.getPontuacao(), a.getPontuacao()));

        // 5. Diversificacao MMR para evitar recomendacoes redundantes
        List<ResultadoRecomendacao> selecionados = new ArrayList<>();
        List<double[]> vetoresSelecionados = new ArrayList<>();
        double lambdaDiversidade = 0.78;

        while (!avaliados.isEmpty() && selecionados.size() < limite) {
            int melhorIdx = 0;
            double melhorMmr = Double.NEGATIVE_INFINITY;

            for (int i = 0; i < avaliados.size(); i++) {
                ResultadoRecomendacao r = avaliados.get(i);
                int idxPool = poolCandidatos.indexOf(r.getFilme());
                double[] vCand = vetoresLatentes[offsetCandidatos + idxPool];

                double maxSimJaEscolhidos = 0.0;
                for (double[] vSel : vetoresSelecionados) {
                    maxSimJaEscolhidos = Math.max(maxSimJaEscolhidos, Math.max(0.0, similaridadeCosseno(vCand, vSel)));
                }

                double mmr = lambdaDiversidade * r.getPontuacao() - (1.0 - lambdaDiversidade) * maxSimJaEscolhidos;
                if (mmr > melhorMmr) {
                    melhorMmr = mmr;
                    melhorIdx = i;
                }
            }

            ResultadoRecomendacao escolhido = avaliados.remove(melhorIdx);
            selecionados.add(escolhido);
            int idxPool = poolCandidatos.indexOf(escolhido.getFilme());
            vetoresSelecionados.add(vetoresLatentes[offsetCandidatos + idxPool]);
        }

        return selecionados;
    }

    public static double similaridadeCosseno(double[] a, double[] b) {
        if (a == null || b == null || a.length != b.length) return 0.0;
        double dot = 0.0, normA = 0.0, normB = 0.0;
        for (int i = 0; i < a.length; i++) {
            dot += a[i] * b[i];
            normA += a[i] * a[i];
            normB += b[i] * b[i];
        }
        if (normA < 1e-12 || normB < 1e-12) return 0.0;
        return dot / (Math.sqrt(normA) * Math.sqrt(normB));
    }

    private static double[][] fatorarSvdTruncado(double[][] M, int k) {
        int m = M.length;
        int n = M[0].length;
        double[][] projecao = new double[m][k];

        double[][] R = new double[m][n];
        for (int i = 0; i < m; i++) {
            System.arraycopy(M[i], 0, R[i], 0, n);
        }

        Random rng = new Random(42);
        for (int comp = 0; comp < k; comp++) {
            double[] v = new double[n];
            for (int j = 0; j < n; j++) v[j] = rng.nextDouble() - 0.5;
            normalizarL2(v);

            double[] u = new double[m];
            for (int iter = 0; iter < 25; iter++) {
                for (int i = 0; i < m; i++) {
                    double sum = 0.0;
                    for (int j = 0; j < n; j++) sum += R[i][j] * v[j];
                    u[i] = sum;
                }
                double normU = norma(u);
                if (normU < 1e-12) break;
                for (int i = 0; i < m; i++) u[i] /= normU;

                for (int j = 0; j < n; j++) {
                    double sum = 0.0;
                    for (int i = 0; i < m; i++) sum += R[i][j] * u[i];
                    v[j] = sum;
                }
                double normV = norma(v);
                if (normV < 1e-12) break;
                for (int j = 0; j < n; j++) v[j] /= normV;
            }

            double sigma = 0.0;
            for (int i = 0; i < m; i++) {
                double rv = 0.0;
                for (int j = 0; j < n; j++) rv += R[i][j] * v[j];
                sigma += u[i] * rv;
            }

            if (sigma < 1e-9) break;

            for (int i = 0; i < m; i++) {
                projecao[i][comp] = u[i] * sigma;
            }

            for (int i = 0; i < m; i++) {
                for (int j = 0; j < n; j++) {
                    R[i][j] -= sigma * u[i] * v[j];
                }
            }
        }
        return projecao;
    }

    private static Map<String, Double> extrairPesosCaracteristicas(Filme f) {
        Map<String, Double> map = new LinkedHashMap<>();
        if (f.getGeneros() != null) {
            for (String g : f.getGeneros()) {
                if (isValido(g)) map.put("GEN:" + g.trim().toLowerCase(), 1.2);
            }
        }
        if (isValido(f.getDiretor())) {
            map.put("DIR:" + f.getDiretor().trim().toLowerCase(), 1.5);
        }
        if (f.getElenco() != null) {
            for (String a : f.getElenco()) {
                if (isValido(a)) map.put("ACT:" + a.trim().toLowerCase(), 0.8);
            }
        }
        if (f.getPaises() != null) {
            for (String p : f.getPaises()) {
                if (isValido(p)) map.put("PAI:" + p.trim().toLowerCase(), 0.6);
            }
        }
        if (isValido(f.getAno()) && f.getAno().length() >= 4) {
            String decada = f.getAno().substring(0, 3) + "0s";
            map.put("DEC:" + decada, 0.5);
        }
        return map;
    }

    private static boolean isValido(String s) {
        if (s == null) return false;
        String t = s.trim().toLowerCase();
        return !t.isEmpty() && !t.equals("desconhecido") && !t.equals("n/i") && !t.equals("geral");
    }

    private static double norma(double[] v) {
        double s = 0.0;
        for (double x : v) s += x * x;
        return Math.sqrt(s);
    }

    private static void normalizarL2(double[] v) {
        double n = norma(v);
        if (n > 1e-12) {
            for (int i = 0; i < v.length; i++) v[i] /= n;
        }
    }

    private static String construirJustificativa(Usuario u, Filme cand, double simLatente) {
        List<String> motivos = new ArrayList<>();
        Map<String, Long> topGeneros = u.getEstatisticasGeneros();
        for (String g : cand.getGeneros()) {
            if (topGeneros.containsKey(g)) {
                motivos.add("gênero " + g);
                if (motivos.size() >= 2) break;
            }
        }
        if (u.getEstatisticasDiretores().containsKey(cand.getDiretor())) {
            motivos.add("direção de " + cand.getDiretor());
        }
        for (String ator : cand.getElenco()) {
            if (u.getEstatisticasAtores().containsKey(ator)) {
                motivos.add("atuação de " + ator);
                break;
            }
        }
        int afinidadePct = (int) Math.round(Math.max(0, Math.min(100, ((simLatente + 1.0) / 2.0) * 100)));
        if (motivos.isEmpty()) {
            return "Afinidade latente de " + afinidadePct + "% com o padrão das suas avaliações.";
        }
        return "Afinidade de " + afinidadePct + "% • Combina com seu interesse em " + String.join(", ", motivos) + ".";
    }

    private static List<ResultadoRecomendacao> gerarFallback(List<Filme> candidatos, int limite, String aviso) {
        return candidatos.stream()
                .sorted((a, b) -> Double.compare(b.getNotaGeral(), a.getNotaGeral()))
                .limit(limite)
                .map(f -> new ResultadoRecomendacao(f, f.getNotaGeral() / 10.0, aviso, true))
                .collect(Collectors.toList());
    }
}