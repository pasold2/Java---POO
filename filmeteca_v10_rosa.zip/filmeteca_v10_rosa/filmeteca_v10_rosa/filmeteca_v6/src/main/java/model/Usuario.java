package model;

import java.io.Serializable;
import java.util.*;
import java.util.stream.Collectors;

public class Usuario implements Serializable {
    private static final long serialVersionUID = 1L;

    private String nome;
    private int idade;
    private String fotoPerfil;
    private String bannerPerfil;
    private List<Filme> filmesVistos;

    // Configurações de Aparência Visual
    private String corPrimaria = "#c83f8d";
    private String corSecundaria = "#e860a8";
    private boolean gradienteAtivo = true;
    private String direcaoGradiente = "VERTICAL";
    private String tipoSombra = "INFERIOR";

    public Usuario(String nome, int idade) {
        this.nome = nome;
        this.idade = idade;
        this.filmesVistos = new ArrayList<>();
    }

    public void adicionarFilmeVisto(Filme filme) {
        if (!filmesVistos.contains(filme)) {
            filme.setVisto(true);
            filmesVistos.add(filme);
        } else {
            for (Filme f : filmesVistos) {
                if (f.getId() == filme.getId()) {
                    f.setVisto(true);
                    if (filme.getNotaUsuario() != null) {
                        f.avaliarEComentar(filme.getNotaUsuario(), filme.getComentario());
                    }
                    break;
                }
            }
        }
    }

    public void removerFilme(Filme filme) {
        filmesVistos.removeIf(f -> f.getId() == filme.getId());
    }

    public List<Filme> getFilmesFavoritos() {
        return filmesVistos.stream()
                .filter(Filme::isFavorito)
                .collect(Collectors.toList());
    }

    public List<Filme> getRankingCompleto() {
        return filmesVistos.stream()
                .filter(f -> f.getNotaUsuario() != null || f.getEloScore() != 1400.0)
                .sorted((a, b) -> {
                    int cmp = Double.compare(b.getEloScore(), a.getEloScore());
                    if (cmp != 0) return cmp;
                    if (b.getNotaUsuario() != null && a.getNotaUsuario() != null) {
                        return Double.compare(b.getNotaUsuario(), a.getNotaUsuario());
                    }
                    return 0;
                })
                .collect(Collectors.toList());
    }

    public int getTotalVistos() {
        return filmesVistos.size();
    }

    public String getGeneroPredominante() {
        if (filmesVistos.isEmpty()) return "Nenhum";
        Map<String, Long> contagem = filmesVistos.stream()
                .flatMap(f -> f.getGeneros().stream())
                .collect(Collectors.groupingBy(g -> g, Collectors.counting()));
        return contagem.entrySet().stream()
                .max(Map.Entry.comparingByValue())
                .map(Map.Entry::getKey)
                .orElse("Geral");
    }

    public Map<String, Long> getEstatisticasDiretores() {
        return filmesVistos.stream()
                .filter(f -> f.getDiretor() != null && !f.getDiretor().equalsIgnoreCase("Desconhecido"))
                .collect(Collectors.groupingBy(Filme::getDiretor, Collectors.counting()))
                .entrySet().stream()
                .sorted(Map.Entry.<String, Long>comparingByValue().reversed())
                .collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue, (e1, e2) -> e1, LinkedHashMap::new));
    }

    public Map<String, Long> getEstatisticasAtores() {
        return filmesVistos.stream()
                .flatMap(f -> f.getElenco().stream())
                .filter(a -> a != null && !a.isBlank())
                .collect(Collectors.groupingBy(a -> a, Collectors.counting()))
                .entrySet().stream()
                .sorted(Map.Entry.<String, Long>comparingByValue().reversed())
                .collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue, (e1, e2) -> e1, LinkedHashMap::new));
    }

    public Map<String, Long> getEstatisticasGeneros() {
        return filmesVistos.stream()
                .flatMap(f -> f.getGeneros().stream())
                .filter(g -> g != null && !g.isBlank())
                .collect(Collectors.groupingBy(g -> g, Collectors.counting()))
                .entrySet().stream()
                .sorted(Map.Entry.<String, Long>comparingByValue().reversed())
                .collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue, (e1, e2) -> e1, LinkedHashMap::new));
    }

    public Map<String, Long> getEstatisticasPaises() {
        return filmesVistos.stream()
                .flatMap(f -> f.getPaises().stream())
                .filter(p -> p != null && !p.isBlank())
                .collect(Collectors.groupingBy(p -> p, Collectors.counting()))
                .entrySet().stream()
                .sorted(Map.Entry.<String, Long>comparingByValue().reversed())
                .collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue, (e1, e2) -> e1, LinkedHashMap::new));
    }

    public Map<String, Long> getEstatisticasAnos() {
        return filmesVistos.stream()
                .filter(f -> f.getAno() != null && !f.getAno().equalsIgnoreCase("N/I"))
                .collect(Collectors.groupingBy(Filme::getAno, Collectors.counting()))
                .entrySet().stream()
                .sorted(Map.Entry.<String, Long>comparingByValue().reversed())
                .collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue, (e1, e2) -> e1, LinkedHashMap::new));
    }

    public void restaurarTemaPadrao() {
        this.corPrimaria = "#c83f8d";
        this.corSecundaria = "#e860a8";
        this.gradienteAtivo = true;
        this.direcaoGradiente = "VERTICAL";
        this.tipoSombra = "INFERIOR";
    }

    // Getters e Setters
    public String getNome() { return nome; }
    public int getIdade() { return idade; }
    public String getFotoPerfil() { return fotoPerfil; }
    public void setFotoPerfil(String fotoPerfil) { this.fotoPerfil = fotoPerfil; }
    public String getBannerPerfil() { return bannerPerfil; }
    public void setBannerPerfil(String bannerPerfil) { this.bannerPerfil = bannerPerfil; }
    public List<Filme> getFilmesVistos() { return filmesVistos; }

    public String getCorPrimaria() { return corPrimaria; }
    public void setCorPrimaria(String corPrimaria) { this.corPrimaria = corPrimaria; }
    public String getCorSecundaria() { return corSecundaria; }
    public void setCorSecundaria(String corSecundaria) { this.corSecundaria = corSecundaria; }
    public boolean isGradienteAtivo() { return gradienteAtivo; }
    public void setGradienteAtivo(boolean gradienteAtivo) { this.gradienteAtivo = gradienteAtivo; }
    public String getDirecaoGradiente() { return direcaoGradiente; }
    public void setDirecaoGradiente(String direcaoGradiente) { this.direcaoGradiente = direcaoGradiente; }
    public String getTipoSombra() { return tipoSombra; }
    public void setTipoSombra(String tipoSombra) { this.tipoSombra = tipoSombra; }
}