package controller;

import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;

public class FormularioController {
    
    @FXML
    private TextField campoNome;
    
    @FXML
    private TextField campoSobrenome;
    
    @FXML
    private TextField campoCurso;
    
    @FXML
    private TextField campoRA;
    
    @FXML
    private PasswordField campoSenha;
    
    @FXML
    private Label labelMensagem;
    
    @FXML
    private void cadastrar() {
        String nome = campoNome.getText();
        String sobrenome = campoSobrenome.getText();
        String curso = campoCurso.getText();
        
        if (nome.isEmpty() || sobrenome.isEmpty() || curso.isEmpty()) {
            labelMensagem.setText("Preencha todos os campos!");
            labelMensagem.setStyle("-fx-text-fill: red;");
            return;
        }
        
        labelMensagem.setText("Cadastro realizado com sucesso! " + 
                             nome + " " + sobrenome + " - " + curso);
        labelMensagem.setStyle("-fx-text-fill: green;");
    }
    
    @FXML
    private void limpar() {
        campoNome.clear();
        campoSobrenome.clear();
        campoCurso.clear();
        campoRA.clear();
        campoSenha.clear();
        labelMensagem.setText("");
    }
    
    @FXML
    private void mostrarAjuda() {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Ajuda");
        alert.setHeaderText("Como usar");
        alert.setContentText("Preencha os campos e clique em Cadastrar");
        alert.showAndWait();
    }
    
    @FXML
    private void mostrarSobre() {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Sobre");
        alert.setHeaderText("Sistema de Cadastro");
        alert.setContentText("Trabalho POO - JavaFX");
        alert.showAndWait();
    }
}