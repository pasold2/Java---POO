import java.util.List;
import javafx.scene.effect.ColorAdjust;


public class Physics {
    public double x;
    public double y;
    public double vx;
    public double vy;
    public double width;
    public double height;

    public final ColorAdjust colorAdjust;


    private static final double[] HUE_COLORS = { 0.0, 0.3, 0.6, 0.9, -0.9, -0.6, -0.3 };
    private int currentColorIndex = 0;

    public Physics(double startX, double startY, double vx, double vy, double width, double height) {
        this.x = startX;
        this.y = startY;
        this.vx = vx;
        this.vy = vy;
        this.width = width;
        this.height = height;
        this.colorAdjust = new ColorAdjust();
    }


    public void update(double dt, double sceneWidth, double sceneHeight, List<Rect> obstacles) {

        x += vx * dt;
        y += vy * dt;

        Rect dvdRect = new Rect(x, y, width, height);
        boolean colorChangedThisFrame = false;


        for (Rect obs : obstacles) {
            if (dvdRect.intersects(obs)) {

                double overlapX = Math.min(dvdRect.getRight(), obs.getRight()) - Math.max(dvdRect.x, obs.x);
                double overlapY = Math.min(dvdRect.getBottom(), obs.getBottom()) - Math.max(dvdRect.y, obs.y);


                if (overlapX < overlapY) {

                    if (dvdRect.getCenterX() < obs.getCenterX()) {
                        x = obs.x - width;
                        vx = -Math.abs(vx);
                    } else {
                        x = obs.getRight();
                        vx = Math.abs(vx);
                    }
                } else {

                    if (dvdRect.getCenterY() < obs.getCenterY()) {
                        y = obs.y - height;
                        vy = -Math.abs(vy);
                    } else {
                        y = obs.getBottom();
                        vy = Math.abs(vy);
                    }
                }

                dvdRect.x = x;
                dvdRect.y = y;

                if (!colorChangedThisFrame) {
                    changeColor();
                    colorChangedThisFrame = true;
                }
            }
        }


        if (x <= 0) {
            x = 0;
            vx = Math.abs(vx);
            if (!colorChangedThisFrame) { changeColor(); colorChangedThisFrame = true; }
        } else if (x + width >= sceneWidth) {
            x = sceneWidth - width;
            vx = -Math.abs(vx);
            if (!colorChangedThisFrame) { changeColor(); colorChangedThisFrame = true; }
        }

        if (y <= 0) {
            y = 0;
            vy = Math.abs(vy);
            if (!colorChangedThisFrame) { changeColor(); colorChangedThisFrame = true; }
        } else if (y + height >= sceneHeight) {
            y = sceneHeight - height;
            vy = -Math.abs(vy);
            if (!colorChangedThisFrame) { changeColor(); colorChangedThisFrame = true; }
        }
    }

    private void changeColor() {
        currentColorIndex = (currentColorIndex + 1) % HUE_COLORS.length;
        colorAdjust.setHue(HUE_COLORS[currentColorIndex]);
    }
}