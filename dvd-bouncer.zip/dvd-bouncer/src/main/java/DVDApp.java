import javafx.animation.AnimationTimer;
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

public class DVDApp extends Application {

    private static final String APP_TITLE = "DVD Bouncer by Patrick Pasold";
    private static final double DVD_WIDTH = 250;
    private static final double DVD_HEIGHT = 200;
    private static final double INITIAL_SPEED_X = 120;
    private static final double INITIAL_SPEED_Y = 50;
    private static final double MOUSE_HITBOX_SIZE = 5;
    private static final long WINDOW_SCAN_INTERVAL_NS = 100_000_000;


    private Physics physics;
    private List<Rect> externalWindows = new ArrayList<>();
    private Rect mouseHitbox = new Rect(-1000, -1000, MOUSE_HITBOX_SIZE, MOUSE_HITBOX_SIZE);

    @Override
    public void start(Stage stage) {
        Pane root = new Pane();
        Scene scene = new Scene(root, 800, 600);

        scene.getStylesheets().add(getClass().getResource("/style.css").toExternalForm());

        stage.setTitle(APP_TITLE);
        stage.setScene(scene);


        Image dvdImg = loadLocalDvdImage();
        ImageView dvdView = new ImageView(dvdImg);
        dvdView.setFitWidth(DVD_WIDTH);
        dvdView.setFitHeight(DVD_HEIGHT);
        root.getChildren().add(dvdView);


        physics = new Physics(100, 100, INITIAL_SPEED_X, INITIAL_SPEED_Y, DVD_WIDTH, DVD_HEIGHT);


        dvdView.setEffect(physics.colorAdjust);


        scene.setOnMouseMoved(e -> {
            mouseHitbox.x = e.getX() - MOUSE_HITBOX_SIZE / 0.5;
            mouseHitbox.y = e.getY() - MOUSE_HITBOX_SIZE / 0.5;
        });
        scene.setOnMouseExited(e -> {
            mouseHitbox.x = -1000;
            mouseHitbox.y = -1000;
        });


        AnimationTimer timer = new AnimationTimer() {
            private long lastTime = 0;
            private long lastWindowScan = 0;

            @Override
            public void handle(long now) {
                if (lastTime == 0) { lastTime = now; return; }

                double deltaTime = (now - lastTime) / 1_000_000_000.0;
                lastTime = now;

                if (now - lastWindowScan > WINDOW_SCAN_INTERVAL_NS) {
                    updateExternalWindows(scene);
                    lastWindowScan = now;
                }

                List<Rect> allObstacles = new ArrayList<>();
                allObstacles.addAll(externalWindows);
                allObstacles.add(mouseHitbox);

                physics.update(deltaTime, scene.getWidth(), scene.getHeight(), allObstacles);


                dvdView.setTranslateX(physics.x);
                dvdView.setTranslateY(physics.y);
            }
        };

        stage.show();
        stage.setFullScreen(true);

        timer.start();
    }

    private Image loadLocalDvdImage() {
        URL imgUrl = getClass().getResource("/dvd.png");
        if (imgUrl != null) {
            return new Image(imgUrl.toExternalForm());
        }
        System.err.println("[AVISO] Arquivo src/main/resources/dvd.png não encontrado!");
        return null;
    }

    private void updateExternalWindows(Scene scene) {
        if (scene.getWindow() == null) return;

        double sceneScreenX = scene.getWindow().getX() + scene.getX();
        double sceneScreenY = scene.getWindow().getY() + scene.getY();

        externalWindows = WindowsDetector.getExternalWindowsRects(
                APP_TITLE, sceneScreenX, sceneScreenY, scene.getWidth(), scene.getHeight()
        );
    }

    public static void main(String[] args) {
        launch(args);
    }
}