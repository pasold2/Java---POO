import com.sun.jna.Pointer;
import com.sun.jna.platform.win32.User32;
import com.sun.jna.platform.win32.WinDef.HWND;
import com.sun.jna.platform.win32.WinDef.RECT;
import com.sun.jna.platform.win32.WinUser.WNDENUMPROC;
import java.util.ArrayList;
import java.util.List;


public class WindowsDetector {


    public static List<Rect> getExternalWindowsRects(String myWindowTitle, double sceneScreenX, double sceneScreenY, double sceneWidth, double sceneHeight) {
        List<Rect> obstacles = new ArrayList<>();


        HWND myHwnd = User32.INSTANCE.FindWindow(null, myWindowTitle);
        Rect sceneRect = new Rect(0, 0, sceneWidth, sceneHeight);


        User32.INSTANCE.EnumWindows(new WNDENUMPROC() {
            @Override
            public boolean callback(HWND hwnd, Pointer arg) {

                if (hwnd.equals(myHwnd)) {
                    return false;
                }


                if (User32.INSTANCE.IsWindowVisible(hwnd)) {
                    RECT rect = new RECT();
                    User32.INSTANCE.GetWindowRect(hwnd, rect);

                    double width = rect.right - rect.left;
                    double height = rect.bottom - rect.top;


                    if (width > 0 && height > 0) {

                        double localX = rect.left - sceneScreenX;
                        double localY = rect.top - sceneScreenY;

                        Rect externalWindowRect = new Rect(localX, localY, width, height);


                        if (externalWindowRect.intersects(sceneRect)) {
                            obstacles.add(externalWindowRect);
                        }
                    }
                }
                return true;
            }
        }, null);

        return obstacles;
    }
}